/************************************************************************************
 *                                                                                  *
 * htmlcopDlg.cpp :: Color Cop - by Jay Prall - Jay@datastic.com                    *
 *                                                                                  *
 * note: all of the files are called Htmlcop, because that's what I originally      *
 *       called it when I first started writing color cop in August of 1999         *
 *                                                                                  *
 * Please do not distribute this file.                                              *
 ************************************************************************************/

#include "stdafx.h"
#include "htmlcop.h"
#include "htmlcopDlg.h"
#include "Label.h"			// used for the Links in the AboutDlg
#include "SystemTray.h"		// used to minimize to the systray
#include "WavTipCtrl.h"		// used to add tooltips to the dialog :)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CLabel	m_maillink;
	CLabel	m_link;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}


void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_MAILLINK, m_maillink);
	DDX_Control(pDX, IDC_LINK, m_link);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//Constants

const char* kpcTrayNotificationMsg_ = "TBHide tray notification";

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopDlg dialog

CHtmlcopDlg::CHtmlcopDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHtmlcopDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHtmlcopDlg)
	m_Greendec = 0;
	m_Bluedec = 0;
	m_Reddec = 0;
	m_Hexcolor = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHtmlcopDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHtmlcopDlg)
	DDX_Control(pDX, IDC_CPreview, m_ColorPreview);
	DDX_Control(pDX, IDC_EXPAND_DIALOG, m_ExpandDialog);
	DDX_Control(pDX, IDC_MAGE, m_Magnifier);
	DDX_Control(pDX, IDC_EYELOC, m_EyeLoc);
	DDX_Text(pDX, IDC_GREEN, m_Greendec);
	DDX_Text(pDX, IDC_BLUE, m_Bluedec);
	DDX_Text(pDX, IDC_RED, m_Reddec);
	DDX_Text(pDX, IDC_HEXCOLOR, m_Hexcolor);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHtmlcopDlg, CDialog)
	//{{AFX_MSG_MAP(CHtmlcopDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_About, OnAbout)
	ON_EN_CHANGE(IDC_GREEN, OnChangeGreen)
	ON_EN_CHANGE(IDC_BLUE, OnChangeBlue)
	ON_EN_CHANGE(IDC_RED, OnChangeRed)
	ON_BN_CLICKED(IDC_ColorPick, OnColorPick)
	ON_BN_CLICKED(IDC_COPYTOCLIP, OnCopytoclip)
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(IDC_HEXCOLOR, OnChangeHexcolor)
	ON_WM_DESTROY()
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	ON_COMMAND(ID_COLOR_REVERSE, OnColorReverse)
	ON_COMMAND(ID_OPTIONS_ALWAYSONTOP, OnOptionsAlwaysontop)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_ALWAYSONTOP, OnUpdateOptionsAlwaysontop)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_DELPHIMODE, OnUpdateOptionsDelphimode)
	ON_COMMAND(ID_OPTIONS_DELPHIMODE, OnOptionsDelphimode)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_AUTOCOPYTOCLIPBOARD, OnUpdateOptionsAutocopytoclipboard)
	ON_COMMAND(ID_OPTIONS_AUTOCOPYTOCLIPBOARD, OnOptionsAutocopytoclipboard)
	ON_COMMAND(ID_COLOR_RANDOM, OnColorRandom)
	ON_UPDATE_COMMAND_UI(ID_VIEW_HTMLHEXMODE, OnUpdateViewHtmlhexmode)
	ON_COMMAND(ID_VIEW_HTMLHEXMODE, OnViewHtmlhexmode)
	ON_COMMAND(ID_FILE_ABOUT, OnFileAbout)
	ON_COMMAND(ID_COLOR_SNAPTOWEBSAFE, OnColorSnaptowebsafe)
	ON_COMMAND(ID_OPTIONS_OMITSYMBOL, OnOptionsOmitsymbol)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_OMITSYMBOL, OnUpdateOptionsOmitsymbol)
	ON_BN_CLICKED(IDC_EXPAND_DIALOG, OnExpandDialog)
	ON_UPDATE_COMMAND_UI(ID_COLOR_SNAPTOWEBSAFE, OnUpdateColorSnaptowebsafe)
	ON_COMMAND(ID_OPTIONS_MINIMIZETOSYSTRAY, OnOptionsMinimizetosystray)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_MINIMIZETOSYSTRAY, OnUpdateOptionsMinimizetosystray)
	ON_COMMAND(ID_OPTIONS_UPPERCASEHEX, OnOptionsUppercasehex)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_UPPERCASEHEX, OnUpdateOptionsUppercasehex)
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_POPUP_SAMPLING_1PIXEL, ChangeTo1pixelSampling)
	ON_UPDATE_COMMAND_UI(ID_POPUP_SAMPLING_1PIXEL, OnUpdatePopupSampling1pixel)
	ON_COMMAND(ID_POPUP_SAMPLING_3BY3AVERAGE, ChangeTo3x3Sampling)
	ON_UPDATE_COMMAND_UI(ID_POPUP_SAMPLING_3BY3AVERAGE, OnUpdatePopupSampling3by3average)
	ON_COMMAND(ID_POPUP_SAMPLING_5BY5AVERAGE, ChangeTo5x5Sampling)
	ON_UPDATE_COMMAND_UI(ID_POPUP_SAMPLING_5BY5AVERAGE, OnUpdatePopupSampling5by5average)
	ON_COMMAND(ID_POPUP_APPLICATION_EXPANDEDDIALOG, OnPopupApplicationExpandeddialog)
	ON_UPDATE_COMMAND_UI(ID_POPUP_APPLICATION_EXPANDEDDIALOG, OnUpdatePopupApplicationExpandeddialog)
	ON_COMMAND(ID_POPUP_HEXMODE_POWERBUILDER, OnPopupHexmodePowerbuilder)
	ON_UPDATE_COMMAND_UI(ID_POPUP_HEXMODE_POWERBUILDER, OnUpdatePopupHexmodePowerbuilder)
	ON_COMMAND(ID_POPUP_MODE_VISUALBASICHEX, OnPopupModeVisualbasichex)
	ON_UPDATE_COMMAND_UI(ID_POPUP_MODE_VISUALBASICHEX, OnUpdatePopupModeVisualbasichex)
	ON_COMMAND(ID_POPUP_MODE_VISUALCHEX, OnPopupModeVisualchex)
	ON_UPDATE_COMMAND_UI(ID_POPUP_MODE_VISUALCHEX, OnUpdatePopupModeVisualchex)
	ON_COMMAND(ID_POPUP_RESTORE, OnPopupRestore)
	ON_COMMAND(ID_POPUP_EXIT, OnPopupExit)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_MOUSEWHEEL()
	ON_WM_QUERYDRAGICON()
	ON_WM_INITMENUPOPUP()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopDlg message handlers

BOOL CHtmlcopDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	SetupSystemMenu();			// add about and always on top to the system menu

//	copmenu.LoadMenu(IDR_COPMENU);

	//SetMenu(&copmenu);

	bool FoundDatFile = LoadPersistentVariables();
	
	if (!FoundDatFile)
	{
		LoadDefaultSettings();	// because there was no settings file
 
	} else {
	
		// We have some settings... lets apply them.
		//if (!m_bExpandedVersion) 
		//	OnExpandDialog();
		//	TestForExpand();
	}
	ToggleOnTop(); //make always on top, unless save file said not to

   	SetupWindowRects();
	SetupStatusBar();

	TestForExpand();	// do not call this before SetupWindowRects();
	
	//EnableToolTips(true);	// Enable tool tips, even though they aren't working yet
	m_tooltip.Create(this);		
	m_tooltip.Activate(TRUE);		

	m_tooltip.SetPopupSound(NULL);	// tool tip sounds off
	m_tooltip.AddTool(GetDlgItem(IDC_MagWindow), 
			IDS_MAG_WINDOW);
	m_tooltip.AddTool(GetDlgItem(IDC_HEXCOLOR), 
			IDS_HEXCOLOR_TOOLTIP);
	m_tooltip.AddTool(GetDlgItem(IDC_EYELOC), 
			IDS_EYEDROPPER_TOOLTIP);

	//IDC_EYELOC

	//IDC_HEXCOLOR


	nTrayNotificationMsg_ = RegisterWindowMessage(kpcTrayNotificationMsg_);
	
	//application variables
	bOldClrExist = m_isEyedropping = m_isMagnifying = FALSE;
	m_OldRed = m_OldBlue = m_OldGreen = 0;
	bMinimized_= (false);
	pTrayIcon_ = 0;
	
//	hIcon_ = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	// new non aliased way to do the icon
	hIcon_ = (HICON)::LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 16, 16, NULL);



	CCopHWND=::GetForegroundWindow();

	SetIcon(m_hIcon, FALSE);	// small icon
    SetIcon(m_hIcon, TRUE);		// big icon


	// PreLoad Cursors
	CWinApp* pApp = AfxGetApp();
	ASSERT(pApp);
	if (pApp)
	{
		VERIFY(m_hEyeCursor = pApp->LoadCursor(IDC_EYE));
		VERIFY(m_hMagCursor = pApp->LoadCursor(IDC_MAGGLASS));
		VERIFY(m_hBlank = AfxGetApp()->LoadIcon(IDI_BLANK));

	}

	SetTimer(1,250,NULL);		// install the timer

	OnconvertRGB();

	GetDlgItem(IDC_RED)->SetFocus();	// set the focus to the Red edit control

	return FALSE;  
}

void CHtmlcopDlg::SetupSystemMenu()
{

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
    ASSERT(IDM_ALWAYSONTOP < 0xF000);

	//get the handle to the control menu
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		// Load string and add 'about cc' to the system menu
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())	
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}

		 // Load stringon top to system menu
		CString strAlwaysMenu;
		strAlwaysMenu.LoadString(IDS_ALWAYSONTOP);
		if (!strAlwaysMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_STRING, IDM_ALWAYSONTOP, strAlwaysMenu);
		}

		// disable maxmize in the system menu
		pSysMenu->EnableMenuItem(SC_MAXIMIZE, MF_BYCOMMAND | MF_GRAYED );

		// disable sizing in the system menu
		pSysMenu->EnableMenuItem(SC_SIZE, MF_BYCOMMAND | MF_GRAYED );
	}
}

bool CHtmlcopDlg::LoadPersistentVariables()
{
	bool retval = false;		// Attempt to open ColorCop.dat

	TCHAR szPath[MAX_PATH];
	if( 0 != GetModuleFileName(AfxGetInstanceHandle(),szPath,sizeof(szPath)) )
	{
		LPTSTR pName = _tcsrchr(szPath, '\\');
		if(!pName)
			pName = szPath;
		_tcscpy(pName, "\\ColorCop5.dat");
	}
	try
	 {
		CFile file;
		if( file.Open(szPath, CFile::modeRead) )
		{
			CArchive ar(&file, CArchive::load);
			Serialize(ar);
			

			//Minimize Close Bug,

			/*

			This is to check to see if the location of colorcop was stored
			as minimized.  programs aren't actually minimized, they seem to 
			just be moved off the screen.  The problem is different 
			operating systems handle this differently:

			Win NT/2000/Me - moves the window to -32000, -32000
			Win98 / 95 - moves the window to 3000,3000

			The follow if checks to see if this is the case, if it is -
			the program is repositioned.
            */

			if (WinLocX < 0 || WinLocY < 0  /*negative*/ 
				|| WinLocX  == 3000 || WinLocY == 3000)
			{
			
				// DEBUG - remove this
			//	char a[90];
			//	sprintf(a,"ColorCop has been moved back onto the screen from %d, %d", WinLocX, WinLocY);
			//	AfxMessageBox(a);

			
				WinLocX = 200;	// default position..  quickfix
				WinLocY = 200;
			}

			SetWindowPos(&wndTopMost,WinLocX,WinLocY, 0, 0, SWP_NOSIZE | WS_EX_TOPMOST);
			
			retval = true;	// if we get this far, everything is cool
		
		} else LoadDefaultSettings();
	}
	catch(CFileException*)
	{
		AfxMessageBox("Trouble loading file");
	}

	return retval;
}


void CHtmlcopDlg::SetupWindowRects()
{
	// setup color window rect based on the Static box
	HWND buttonhand;
	CWnd::GetDlgItem(IDC_CPreview,&buttonhand);
	::GetWindowRect(buttonhand,&buttonrect);
	CWnd::ScreenToClient(&buttonrect);
	
	HWND maghand;
	CWnd::GetDlgItem(IDC_MagWindow,&maghand);
	::GetWindowRect(maghand, &magrect);
	CWnd::ScreenToClient(magrect);

	RECT exprect;
	HWND expandbutton;
	CWnd::GetDlgItem(IDC_EXPAND_DIALOG, &expandbutton);
	::GetWindowRect(expandbutton, &exprect);
	CWnd::ScreenToClient(&exprect);

	// Get a rect of the entire window.
	CWnd::GetWindowRect(&CCopRect);
	CWnd::ScreenToClient(&CCopRect);
	CCopsmRect = CCopRect;			// copy rect



	// large sizes
	lgWidth = CCopRect.right - CCopRect.left;
	lgHeight = CCopRect.bottom - CCopRect.top;

	// small sizes
	smWidth = (exprect.right - CCopRect.left) + 11;
	smHeight = (exprect.bottom - CCopRect.top) + 11;

}

void CHtmlcopDlg::LoadDefaultSettings()
{
		// This function is called when we can't find a .DAT file
		// with the persistent variables, or it was an old dat file

		// OK - better set the default settings and custom colors

		m_Reddec   = 51;	// load navy blue websafe, a cool color to start with
		m_Greendec = 51;
		m_Bluedec  = 153;

		bVisualBasic = FALSE;
		bPowerbuilder = FALSE;
		bVisualC = FALSE;

		bDelphi=0;	    //View
		bHTML=1;	    //View  - default to HTML mode

		bOnTop=1;	    //Options	- default always on top
		bAutoCopy=1;    //Options	- default autocopy
		bOmitPound=0;   //Options
		bUppercaseHex=1;//use uppercase hex by default 
		
		bSnaptoWebsafe=0;
		bMinimizetoTray = 0;	// normal minimize by default

		m_bExpandedVersion = true;

		SampleRate = 1;   // default to 1 pixel sampling, not 3x3 or 5x5

		// set all custom color blocks to white
		for(int initcolor = 0; initcolor < 16; initcolor++)
			CustColorBank[initcolor] = 0x00FFFFFF;  
		            //C++ explicit hex 0x00bbggrr 

}

void CHtmlcopDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	// this is function is called when the user selects an item 
	// from the system menu. (right clicking on the minimized program,
	// or right clicking on the system icon
	
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	} else if ((nID & 0xFFF0) == IDM_ALWAYSONTOP)
	{
		bOnTop=bOnTop?FALSE:TRUE;
		ToggleOnTop();
	
		CMenu* pSysMenu = GetSystemMenu(FALSE);
		if (pSysMenu != NULL)
		{
			if (bOnTop) 
			{
				// check the menu item
				pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_CHECKED);
			} else {
				pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_UNCHECKED);
				// uncheck the item
			}
		}
	}
	else
	{
		BOOL bOldMin = bMinimized;	// remember previous state

		if (nID == SC_MINIMIZE) {
			bMinimized = true;
		} else if (nID == SC_RESTORE) {
			bMinimized = false;
		}

		CDialog::OnSysCommand(nID, lParam);

		if (bOldMin != bMinimized)
		{
			SetupTrayIcon();
			SetupTaskBarButton();

		}
	}

}

void CHtmlcopDlg::SetupTaskBarButton()
{
	if ((bMinimized) && (bMinimizetoTray != 0)) 
	{
		ShowWindow(SW_HIDE);
	//	AfxMessageBox("not implemented yet");

	}
	else {
		ShowWindow(SW_SHOW);
	}

}

void CHtmlcopDlg::SetupTrayIcon()
{
	if (bMinimized && (pTrayIcon_ == 0) && (bMinimizetoTray != FALSE)) {
		pTrayIcon_ = new CSystemTray;
		pTrayIcon_->Create(0, nTrayNotificationMsg_, "Color Cop 5",
				hIcon_, IDR_SYSTRAY_MENU);
//		AfxMessageBox("created");
	}
	else {
		delete pTrayIcon_;
		pTrayIcon_ = 0;
	}
}

void CHtmlcopDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); 
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();

		DisplayColor();	// keep the color window showing

		CDC *pDC=GetDC();

        if (hBitmap)
          {
			hdc = ::GetDC(CCopHWND);   

			hdcMem = ::CreateCompatibleDC (hdc);
            ::SelectObject (hdcMem, hBitmap) ;

			// gets info about the bitmap.. might not need this
           //GetObject (hBitmap, sizeof (BITMAP), NULL) ;

               ::SetStretchBltMode (hdc, COLORONCOLOR);
		   
/*             ::StretchBlt (hdc, 
			                 buttonrect.TopLeft().x + 3, buttonrect.TopLeft().y + 175, // upper left dest
				             buttonrect.Width(), buttonrect.Height(),  // width of dest rect
                             hdcMem,  // source dc
							 0, 0,	  // upper left source
							 18, 15,  // W x H of source
							 SRCCOPY);// mode
*/

			 //  CDC* tmpDC;
			 //  CBitmap tmpBitmap;

			 //   tmpBitmap.FromHandle(hBitmap);

			 //  if (hBitmap == tmpBitmap.HBITMAP()) 
			 //		AfxMessageBox("attached correctly");
			 //   tmpBitmap.LoadBitmap(IDB_BITMAP1);

			 //tmpDC->CreateCompatibleDC(NULL);
			 // tmpDC->SelectObject(tmpBitmap);

			//	pDC->BitBlt(0,0, 10, 10, tmpDC, 0, 0, SRCCOPY);

			   // the StretchBlt function copies a bitmap from a source rectangle into a destination rectangle
			   ::StretchBlt (hdc, 
				             magrect.TopLeft().x+2, magrect.TopLeft().y+2 , // upper left dest
				             magrect.Width()-4, magrect.Height()-4,  // width of dest rect
                             hdcMem,  // source dc
							 0, 0,	  // upper left source
							 18, 15,  // W x H of source
							 SRCCOPY);// mode

			//	Beep(400,40);

		/*	   pDC->StretchBlt(magrect.TopLeft().x, magrect.TopLeft().y,
				               magrect.Width(), magrect.Height(),
							   tmpDC,
							   0,0,
							   18, 15,
							   SRCCOPY);
		*/
				::DeleteDC (hdcMem);	// temporary DC
				::ReleaseDC (::GetForegroundWindow(), hdc);
          }

		pDC->DrawEdge(magrect, EDGE_SUNKEN, BF_RECT);
		ReleaseDC(pDC);
	}
}

void CHtmlcopDlg::OnconvertRGB() 
{
    TestForWebsafe();	// before conversion

	if (bHTML)
	{
		m_Hexcolor.Format("#%.2x%.2x%.2x", m_Reddec, m_Greendec, m_Bluedec);
	}
	else if (bDelphi) // in Delphi Hex Mode
	{
		m_Hexcolor.Format("$00%.2x%.2x%.2x", m_Bluedec, m_Greendec, m_Reddec);
	} else if (bPowerbuilder) {

		m_Hexcolor.Format("%d", (65536 * m_Bluedec) + (256 * m_Greendec) + (m_Reddec));

	} else if (bVisualBasic) {
		m_Hexcolor.Format("&H%.2x%.2x%.2x", m_Bluedec, m_Greendec, m_Reddec);
		
	} else if (bVisualC) {
		m_Hexcolor.Format("0x00%.2x%.2x%.2x", m_Bluedec, m_Greendec, m_Reddec);
	} else {
			Beep(400,60);	// this should never happen
	}



   if (!bVisualC)	// don't allow upper case vc++ codes
		TestForUpperHex();	// after conversion
	    

    if (bOmitPound && bHTML) {
        if (m_Hexcolor.Left(1) == '#') { m_Hexcolor.Delete(0); }
    }
    else if (bOmitPound && bDelphi) {
        if (m_Hexcolor.Left(1) == '$') { m_Hexcolor.Delete(0); }
    }

	UpdateData(false); //send m_Hexcolor back to edit control
	
	OnCopytoclip();
	DisplayColor();
}

void CHtmlcopDlg::OnconvertHEX() 
{
	TestForWebsafe();		// before

	if (bHTML)
	{	
		if ((m_Greendec==0) && (m_Bluedec==0) && (m_Reddec!=0)) 
		{
			m_Hexcolor.Format("#%.2x0000",m_Reddec);
		}
		else if ((m_Greendec!=0) && (m_Bluedec==0) && (m_Reddec!=0)) 
		{
			m_Hexcolor.Format("#%.2x%.2x00", m_Reddec, m_Greendec);
		}
		else 
		{
			m_Hexcolor.Format("#%.2x%.2x%.2x", m_Reddec, m_Greendec, m_Bluedec);
		}
	}
	else
		m_Hexcolor.Format("$00%.2x%.2x%.2x", m_Bluedec, m_Greendec, m_Reddec);

    if (bOmitPound && bHTML) {
        if (m_Hexcolor.Left(1) == '#') 
			m_Hexcolor.Delete(0);
    }
    else if (bOmitPound && bDelphi) {
        if (m_Hexcolor.Left(1) == '$') 
			m_Hexcolor.Delete(0);
    }
	
    DisplayColor();
	OnCopytoclip();
}



void CHtmlcopDlg::DisplayColor()
{	
	CDC *pDC = GetDC();

	CBrush thecolor(RGB(m_Reddec,m_Greendec,m_Bluedec));	// create the brush to paint with

	pDC->FillRect(buttonrect, &thecolor);
	
/*if (bSnaptoWebsafe)
	{

	}*/
	pDC->DrawEdge(buttonrect, EDGE_SUNKEN, BF_RECT);

	//pDC->LineTo(magrect.TopLeft().x, magrect.TopLeft().y);
   // pDC->FillRect(magrect, &thecolor);

	ReleaseDC(pDC);
	return;
}

void CHtmlcopDlg::OnAbout() 
{
	CAboutDlg dlg; 
	dlg.DoModal();
}

void CHtmlcopDlg::OnChangeGreen() 
{
	UpdateData(true); 
	if (m_Greendec > 255)
	{ 
		m_Greendec = 255;
		UpdateData(false);
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnChangeBlue() 
{
	UpdateData(true); 
	if (m_Bluedec>255)
	{ 
		m_Bluedec=255;
		UpdateData(false);
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnChangeRed() 
{
	UpdateData();
	if (m_Reddec>255)
	{ 
		m_Reddec = 255;
		UpdateData(false);
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnColorPick() 
{
	// set up the common windows color dialog
	COLORREF temp;
	CColorDialog dlgcolor;
	dlgcolor.m_cc.rgbResult = RGB(m_Reddec,m_Greendec,m_Bluedec);
	dlgcolor.m_cc.Flags = CC_RGBINIT | CC_FULLOPEN;
	dlgcolor.m_cc.lpCustColors = CustColorBank;		// load up the Custom colors

	// show the dialog
	if (dlgcolor.DoModal() == IDOK)	
	{
		// if they pressed OK
		temp=dlgcolor.GetColor();

		m_Reddec=GetRValue(temp);
		m_Greendec=GetGValue(temp);
		m_Bluedec=GetBValue(temp);

		UpdateData(false);
		OnconvertRGB();
	}
	// else if they didn't hit OK, do nothing

	// safe check
	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
}

void CHtmlcopDlg::OnCopytoclip() 
{
	// win32 api calls
	HWND CCopHWND=::GetForegroundWindow();		// get a handle to the app window
	
	if(bAutoCopy)	// the option to auto copy to the clipboard is ON
	{
		if(::OpenClipboard(CCopHWND))
		{
			HGLOBAL clipbuffer;
  			char * buffer;
			::EmptyClipboard();
			clipbuffer=::GlobalAlloc(GMEM_DDESHARE, m_Hexcolor.GetLength()+1);
			buffer = (char *) GlobalLock(clipbuffer);
			strcpy(buffer, LPCSTR(m_Hexcolor));
			::GlobalUnlock(clipbuffer);
			::SetClipboardData(CF_TEXT,clipbuffer);
			::CloseClipboard();
		}
	}
	return;		
}

void CHtmlcopDlg::StopCapture()
{
	// we don't want to capture anymore, they let up the left mouse button, or hit ESC
	
	m_isMagnifying = m_isEyedropping = FALSE;
	SetWindowText(_T("Color Cop BETA"));
	m_StatBar.SetText("", 0, 0);
	ReleaseCapture();
	
	// put the icons back in their holders
	m_EyeLoc.SetIcon(m_hEyeCursor);
	m_Magnifier.SetIcon(m_hMagCursor);
	SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));	// put standard cursor back on
	return;
}

void CHtmlcopDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// the left mouse button was pressed, lets find out where

	CWnd* pWnd = ChildWindowFromPoint(point);
	if (pWnd && pWnd->GetSafeHwnd() == m_EyeLoc.GetSafeHwnd())	
		// left mouse button down on the eyedropper
	{
		m_isEyedropping = true;
		SetCapture();
		m_EyeLoc.SetIcon(m_hBlank);
		SetCursor(m_hEyeCursor);

	} else if (pWnd && pWnd->GetSafeHwnd() == m_Magnifier.GetSafeHwnd()) {	
		      //  left mouse button down on the magnifier

		SetCursor(m_hMagCursor);
		m_isMagnifying = true;
		SetCapture();
		m_Magnifier.SetIcon(m_hBlank);

	} else {  //  left mouse button down somewhere else in the app

		// To allow the user to drag the window by left clicking anywhere
		// in the app, we need to fake windows into thinking the user
		// has left clicked on the  the caption, Note: does not maximize on double click
		// from MSDN:
		//
		//		The WM_NCLBUTTONDOWN message is posted when the user presses 
		//		the left mouse button while the cursor is within the nonclient 
		//		area of a window.
		
		PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
	}
	CDialog::OnLButtonDown(nFlags, point);
}

void CHtmlcopDlg::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CWnd* pWnd = ChildWindowFromPoint(point);

	if (pWnd && pWnd->GetSafeHwnd() == m_ColorPreview.GetSafeHwnd())	
	{
		OnColorPick();	// user double clicked in the color preview control
						// open custom color dialog
	}
	CDialog::OnLButtonDblClk(nFlags, point);
}


void CHtmlcopDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// left mouse buttom was released
	// OK - no more eyedropping or magnifying

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
	
	CDialog::OnLButtonUp(nFlags, point);	
}

void CHtmlcopDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// the left mouse button was pressed, lets find out where

/*	CWnd* pWnd = ChildWindowFromPoint(point);
	if (pWnd && pWnd->GetSafeHwnd() == m_EyeLoc.GetSafeHwnd())	
		// left mouse button down on the eyedropper
	{
		SetStatusBarText(_T("Eyedropper"));

	} else if (pWnd && pWnd->GetSafeHwnd() == m_Magnifier.GetSafeHwnd()) {	
		      //  left mouse button down on the magnifier
		SetStatusBarText(_T("Magnifier"));

	} */
	ClientToScreen(&point); //use screen coordinates..
	
	if (m_isEyedropping)	// is the eyedropper in use?
	{

		COLORREF crefxy;
		hdc = ::GetDC(NULL);

		if (SampleRate == 1)	// only sample one pixel.
		{
			crefxy=::GetPixel(hdc, point.x, point.y);
		
			m_Reddec   = GetRValue(crefxy);
			m_Greendec = GetGValue(crefxy);
			m_Bluedec  = GetBValue(crefxy);
		} else {
			// the user wants to sample a 3x3 or a 5x5 average of pixels.
			AveragePixelArea(hdc, &m_Reddec, &m_Greendec, &m_Bluedec, point);
		}
		::ReleaseDC (::GetForegroundWindow(), hdc);	// free up the memory


		UpdateData(false);	// update vars
		OnconvertRGB();

	} else if (m_isMagnifying) {		// or are we magnifiying??
	
		if (hBitmap)	// delete the old bitmap, right before we get a new one
        {
			DeleteObject (hBitmap) ;
            hBitmap = NULL ;
        }

		hdc = ::GetDC(NULL);
		
        hdcMem = ::CreateCompatibleDC(hdc);
		hBitmap = CreateCompatibleBitmap(hdc, 18, 15);

		::SelectObject(hdcMem, hBitmap);

        ::StretchBlt (hdcMem,			// destination DC
			          0, 0,				// destination upper left
					  18, 15,			// width of destination
                      hdc,				// source DC
					  point.x, point.y, // upper left of source
					  18, 15,			// width of source
    				  SRCCOPY);			// raster mode
		
        ::DeleteDC (hdcMem);
		::ReleaseDC (::GetForegroundWindow(), hdc);		// free up memory

		InvalidateRect(NULL, false); // go redraw... but don't erase or it will flicker
	}

	CDialog::OnMouseMove(nFlags, point);
}


BOOL CHtmlcopDlg::PreTranslateMessage(MSG* pMsg) 
{	

	CPoint Temp;
	Temp.x = LOWORD(pMsg->lParam);
	Temp.y = HIWORD(pMsg->lParam);

	//if (m_isMagnifying)
	//OnMouseMove(WM_LBUTTONDOWN, Temp);

	m_tooltip.RelayEvent(pMsg);	// let the tooltip handle the msg too


	// fix the WinHelp problem...  test to see if F1 is being pressed
	if (pMsg->message == 0x4d)
	{		
		if (GetKeyState(VK_SHIFT) >= 0)		
		{			AfxGetApp()->WinHelp(0, HELP_CONTENTS);		// fire help
					return TRUE;
		}
	}

	/************************************************
	 * ESC key Check
     * - hitting the escape key, should only stop the 
	 *   eyedropper or magnifing glass and should not 
	 *   exit the app
     ************************************************/

	if (pMsg->message == WM_KEYDOWN)
		if (pMsg->wParam == VK_ESCAPE) 
		{
			if (m_isEyedropping || m_isMagnifying)		// dropper or magnifier in use
			{
				StopCapture();
				return TRUE;
			}
		}
	
	// escape wasn't pressed
/*
          �80  50 P 
65  41 A  �81  51 Q 
66  42 B  �82  52 R 
67  43 C  �83  53 S 
68  44 D  �84  54 T 
69  45 E  �85  55 U 
70  46 F  �86  56 V 
71  47 G  �87  57 W 
72  48 H  �88  58 X 
73  49 I  �89  59 Y 
74  4A J  �90  5A Z 
75  4B K  �91  5B [ 
76  4C L  �92  5C \ 
77  4D M  �93  5D ] 
78  4E N  �94  5E ^ 
79  4F O  �95  5F _ 

  */
	if ((pMsg->message == WM_KEYDOWN) && (GetAsyncKeyState(VK_CONTROL) < 0))
	{
		switch (pMsg->wParam)
		{
			case 49:	// CTRL+1 
				ChangeTo1pixelSampling();
				return TRUE;			// don't return control (or it will beep)
			break;
			case 51:	// CTRL+3 
				ChangeTo3x3Sampling();
				return TRUE;			
			break;
			case 53:	// CTRL+5 
				ChangeTo5x5Sampling(); 
				return TRUE;		
			break;
			case 66:	// CTRL+B 
				OnPopupModeVisualbasichex();	
				return TRUE;		
			break;
			case 68:	// CTRL+D 
				OnOptionsDelphimode();	
				return TRUE;		
			break;
			case 69:	// CTRL+E 
				OnExpandDialog();	
				return TRUE;		
			break;

			case 72:	// CTRL+H 
				OnViewHtmlhexmode();	
				return TRUE;		
			break;
			case 75:	// CTRL+K 
				OnOptionsAutocopytoclipboard();	
				return TRUE;		
			break;
			case 77:	// CTRL+M 
				OnOptionsMinimizetosystray();	
				return TRUE;		
			break;
			case 79:	// CTRL+O 
				OnOptionsOmitsymbol();	
				return TRUE;		
			break;
			case 80:	// CTRL+P 
				OnPopupHexmodePowerbuilder();	
				return TRUE;		
			break;
			case 82:	// CTRL+R 
				OnColorReverse();
				return TRUE;		
			break;
			case 84:	// CTRL+T 
				OnOptionsAlwaysontop();
				return TRUE;		
			break;
			case 85:	// CTRL+U 
				OnOptionsUppercasehex();
				return TRUE;		
			break;
			case 87:	// CTRL+W 
				OnColorSnaptowebsafe();
				return TRUE;			
			break;
			case 89:	// CTRL+Y 
				OnPopupModeVisualchex();
				return TRUE;			
			break;
			case 90:	// CTRL+Z 
				OnColorRandom();
				return TRUE;			
			break;

		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}



void CHtmlcopDlg::OnChangeHexcolor() 
{
	// the user is typing in the hex edit control
	// or they pasted a hex code.  
	// OK - parse out the RGB values and convert
	
	int hexrange,offset;
	
	UpdateData(1);	// save from control to m_Hexcolor
	int hexsize=0;
	hexsize=m_Hexcolor.GetLength();

	if (bHTML)
	{
		  
		if (m_Hexcolor.Left(1) =='#') 
		{	 
			hexrange=5;
			offset=1;
		}
		else
		{
			hexrange=6;
	 		offset=0;
		}

		while (hexsize>hexrange)
		{
			//AfxMessageBox ("you went too far");
			m_Hexcolor.Delete(6+offset);
			hexsize--;
		}
		m_Reddec=m_Greendec=m_Bluedec=0;
		ParseHTML(m_Hexcolor);

	}
	else //Delphi hex change
	{
		if (m_Hexcolor.Left(1) =='$') 
		{	 
			hexrange=7;
			offset=1;
		}
		else
		{
			hexrange=8;
	 		offset=0;
		}
		
		while (hexsize>hexrange)
		{
			//AfxMessageBox ("you went too far");
			m_Hexcolor.Delete(8+offset);
			hexsize--;
		}
		m_Reddec=m_Greendec=m_Bluedec=0;
		ParseDelphi(m_Hexcolor);
	}
}


void CHtmlcopDlg::ParseDelphi(CString inst)
{
	// they are typing in delphi hex codes
	// determine the RGB values

	int strLen=inst.GetLength();

	if (strLen < 3)	
	{		
		m_Reddec=m_Greendec=m_Bluedec=0;
		UpdateData(false); 
		return;		
	}

	if (inst.Left(1)=='$') inst.Delete(0);
	inst.Delete(0);
	inst.Delete(0);
	m_Bluedec = strtoul( inst.Left(2), NULL, 16);
    inst.Delete(0);
	inst.Delete(0);
	m_Greendec = strtoul( inst.Left(2), NULL, 16);
	inst.Delete(0);
	inst.Delete(0);
	m_Reddec = strtoul( inst.Left(2), NULL, 16);

	UpdateData(0);

	OnconvertHEX();
	return;
}


void CHtmlcopDlg::ParseHTML(CString inst)
{
	// the user is typing in HTML hex codes
	// get the RGB values

	if (inst.Left(1) == '#')	
		inst.Delete(0);  

	int strLen = inst.GetLength();

	if (strLen < 2)	
		return;

	m_Reddec = strtoul( inst.Left(2), NULL, 16);

	inst.Delete(0);
	inst.Delete(0);
	m_Greendec = strtoul( inst.Left(2), NULL, 16);
	inst.Delete(0);
	inst.Delete(0);
	m_Bluedec = strtoul( inst.Left(2), NULL, 16);
	UpdateData(0);

	OnconvertHEX();
	return;
}


void CHtmlcopDlg::OnDestroy() 
{
	// The app is about to close, save the variables

	CDialog::OnDestroy();
	
	tagRECT *winSize = new tagRECT;
	GetWindowRect(winSize);
	WinLocX = winSize->left;		// Store x,y
	WinLocY = winSize->top;		// in variables
	

	TCHAR szPath[MAX_PATH];
	if(0!=GetModuleFileName(AfxGetInstanceHandle(),szPath,sizeof(szPath)))
	{
		LPTSTR pName = _tcsrchr(szPath, '\\');
		if(!pName)
			pName = szPath;
		_tcscpy(pName,"\\ColorCop5.dat");
	}
	try	// to serialize the variables
	{
		CFile file;
		if(file.Open(szPath,CFile::modeWrite|CFile::modeCreate))
		{
		CArchive ar(&file, CArchive::store);
		Serialize(ar);
		}
	}
	catch(CFileException*)
	{
		//something bad happened, we couldn't save the variables..
		AfxMessageBox("There was an error");
	}


}

void CHtmlcopDlg::Serialize(CArchive& ar) 
{

	// persistent variables

	if (ar.IsStoring())
	{	// store variables to file
		try
		{
			ar << m_Reddec;
			ar << m_Greendec;
			ar << m_Bluedec;
			ar << bAutoCopy;
			ar << bOmitPound;
			ar << bOnTop;
			ar << bDelphi;
			ar << bHTML;
			ar << WinLocX;
			ar << WinLocY;
			for (int j = 0; j<16; j++)		//save custom color values from array
				ar << CustColorBank[j];
			ar << m_bExpandedVersion;
			ar << bSnaptoWebsafe;
			ar << bUppercaseHex;
			ar << bMinimizetoTray;
			ar << SampleRate;
			ar << bPowerbuilder;
			ar << bVisualBasic;
			ar << bVisualC;

		} catch (CArchiveException*) {
			AfxMessageBox(_T("Error writing to colorcop.dat"));
		}
	}
	else
	{	// load variables from file
		try
		{
			ar >> m_Reddec;
			ar >> m_Greendec;
			ar >> m_Bluedec;
			ar >> bAutoCopy;
			ar >> bOmitPound;
			ar >> bOnTop;
			ar >> bDelphi;
			ar >> bHTML;
			ar >> WinLocX;
			ar >> WinLocY;
			for (int j = 0; j<16; j++)		//load custom color values to array
				ar >> CustColorBank[j];
			ar >> m_bExpandedVersion;
			ar >> bSnaptoWebsafe;
			ar >> bUppercaseHex;
			ar >> bMinimizetoTray;
			ar >> SampleRate;
			ar >> bPowerbuilder;
			ar >> bVisualBasic;
			ar >> bVisualC;
	
		} catch (CArchiveException*) {
			// oops... we've got trouble - let them know
			// This will happen when using an old .DAT file
			// which doesn't have all the variables saved.
			// it could also happen when a user tampers with the binary
			// colorcop.dat file

			AfxMessageBox(_T("Error: You were either using an older version of ColorCop.dat, or it has been tampered with.\nDefault settings will be used."));
			LoadDefaultSettings();
		}
	}
}


void CHtmlcopDlg::OnFileExit() 
{	
	// the user wants to exit from the file menu
	OnDestroy();
	exit(1);	
}

void CHtmlcopDlg::OnOptionsAlwaysontop() 
{
	bOnTop=bOnTop?FALSE:TRUE;
	ToggleOnTop();
}


void CHtmlcopDlg::ToggleOnTop()
{
	if (bOnTop) // Make Always on Top
	{
		SetStatusBarText(_T("Always on Top ON"));
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | WS_EX_TOPMOST);
	}
	else		// Not always on top, NORMAL
	{
		SetStatusBarText(_T("Always on Top OFF"));
		::SetWindowPos(GetSafeHwnd(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}

	// Make sure the checkbox for always on top on the system menu
	// is the same as the checkbox in the dialog menu
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		if (bOnTop) 
			pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_CHECKED);		// check the menu item
		else 
			pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_UNCHECKED);		// uncheck the item
	}


}


void CHtmlcopDlg::OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu) 
{        
	// this function is called when the top level 
	// menu items are selected.
	UpdateMenu(pMenu);
}

void CHtmlcopDlg::UpdateMenu(CMenu* pMenu)
{
	// this function loops through each menu item and updates the checkboxes and radio buttons

	CCmdUI cmdUI;
	for (UINT n = 0; n < pMenu->GetMenuItemCount(); ++n)
	{
		CMenu* pSubMenu = pMenu->GetSubMenu(n);
        if (pSubMenu == NULL)
        {
			cmdUI.m_nIndexMax = pMenu->GetMenuItemCount();
            for (UINT i = 0; i < cmdUI.m_nIndexMax;++i)
            {
				cmdUI.m_nIndex = i;
                cmdUI.m_nID = pMenu->GetMenuItemID(i);
                cmdUI.m_pMenu = pMenu;
                cmdUI.DoUpdate(this, FALSE);
            }
        }
    }
}

void CHtmlcopDlg::OnUpdateOptionsDelphimode(CCmdUI* pCmdUI)          
{   
	pCmdUI->SetRadio(bDelphi);   
}

void CHtmlcopDlg::OnUpdateViewHtmlhexmode(CCmdUI* pCmdUI)            
{   
	pCmdUI->SetRadio(bHTML);     
}

void CHtmlcopDlg::OnUpdateOptionsAutocopytoclipboard(CCmdUI* pCmdUI) 
{   
	pCmdUI->SetCheck(bAutoCopy); 
}

void CHtmlcopDlg::OnUpdateOptionsAlwaysontop(CCmdUI* pCmdUI)         
{   
	pCmdUI->SetCheck(bOnTop);
}

void CHtmlcopDlg::OnOptionsDelphimode() 
{
	m_StatBar.SetText("Delphi Hex Mode ON", 0, 0);
	if (!bDelphi)
	{
		bHTML = FALSE;
		bDelphi = TRUE;
		bPowerbuilder = FALSE;
		bVisualBasic = FALSE;
		bVisualC = FALSE;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnViewHtmlhexmode() 
{
	m_StatBar.SetText("HTML Hex Mode ON", 0, 0);
	if (!bHTML)
	{
		bHTML = TRUE;
		bDelphi = FALSE;
		bPowerbuilder = FALSE;
		bVisualBasic = FALSE;
		bVisualC = FALSE;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnOptionsAutocopytoclipboard() 
{
	bAutoCopy=bAutoCopy?FALSE:TRUE;
	if (bAutoCopy) 
		OnCopytoclip();
}

void CHtmlcopDlg::OnColorRandom() 
{
	// Generates a random color and updates
	// current decimal value MOD 256 - make a random value from 0 to 255
    srand((unsigned) time(NULL));	// seed with the timer to actually make it random
    m_Reddec   = rand() % 256;
	m_Greendec = rand() % 256;
	m_Bluedec  = rand() % 256;
	UpdateData(false);
	OnconvertRGB();

	SetStatusBarText(_T("Random Color Generated"));
}

void CHtmlcopDlg::OnColorReverse() 
{
	// Reverse the current colors.
	// ABS (current decimal value - 255)  then update

	SetStatusBarText(_T("Color Reversed"));

	m_Reddec   = abs(m_Reddec - 255);
	m_Greendec = abs(m_Greendec- 255);
	m_Bluedec  = abs(m_Bluedec - 255);
	UpdateData(false);
	OnconvertRGB();
}

void CHtmlcopDlg::OnFileAbout() 
{
	// bring up the About Dialog

	CAboutDlg dlg; 
	dlg.DoModal();
}

void CHtmlcopDlg::OnColorSnaptowebsafe() 
{

	bSnaptoWebsafe=bSnaptoWebsafe?FALSE:TRUE;
	
	if (bSnaptoWebsafe)
		SetStatusBarText(_T("Snap to Websafe ON"));
	else
		SetStatusBarText(_T("Snap to Websafe OFF"));

	if ((!bSnaptoWebsafe) && (bOldClrExist)) 
	{
		// the user switched snap to websafe off, which means it was previously on
		// revert back to the saved colors
		m_Reddec   = m_OldRed;
		m_Greendec = m_OldGreen;
		m_Bluedec  = m_OldBlue;

	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnUpdateColorSnaptowebsafe(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(bSnaptoWebsafe); 
}

void CHtmlcopDlg::TestForWebsafe()
{
	// websafe colors are multiples of 51
	if (bSnaptoWebsafe)
	{
		bOldClrExist = true;	// let the other function know we have an old color
		m_OldRed   = m_Reddec;	// backup the actual values incase they unsnap
		m_OldGreen = m_Greendec;
		m_OldBlue  = m_Bluedec;

		m_Reddec   = DecimaltoWebsafe(m_Reddec);
		m_Greendec = DecimaltoWebsafe(m_Greendec);
		m_Bluedec  = DecimaltoWebsafe(m_Bluedec);
	} //else  do nothing
}

int CHtmlcopDlg::DecimaltoWebsafe(int originalDec)
{
	int offset = originalDec % 51;
	
	// see if this value is already websafe
	if (offset == 0)
	{
		return originalDec;		// Great, it was already a multiple of 51;
	} else {
		if (offset < 25)
			return originalDec - (offset);
		else
			return (((originalDec / 51) + 1) * 51);
	}
}

void CHtmlcopDlg::OnOptionsOmitsymbol() 
{
    bOmitPound=bOmitPound?FALSE:TRUE;
	if (bOmitPound)
		SetStatusBarText(_T("Symbol Omited"));
	else
		SetStatusBarText(_T("Symbol Included"));

    FigurePound();
}

void CHtmlcopDlg::FigurePound() 
{
	// This function adds or removes characters from the hex edit control

    if (bOmitPound) 
	{
		if (bHTML) {
			if (m_Hexcolor.Left(1) == '#')			// remove the # is it exists
				m_Hexcolor.Delete(0); 
		} else if (bDelphi) {
	        if (m_Hexcolor.Left(1) == '$') 
				m_Hexcolor.Delete(0);
		}
    }
    else
    {
		if (bHTML) {
			if (m_Hexcolor.Left(1) != '#')  
				m_Hexcolor = "#" + m_Hexcolor;		// add the # if it exsits
		} else if (bDelphi) {
	        if (m_Hexcolor.Left(1) != '$') 
				m_Hexcolor = "$" + m_Hexcolor;
		}
    }
	UpdateData(false);								// update changes to the edit control (m_Hexcolor)
}

void CHtmlcopDlg::OnUpdateOptionsOmitsymbol(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(bOmitPound);

    if (bDelphi) {
        pCmdUI->SetText(_T("&Omit $ Symbol\tCtrl+O"));
    }
    else if (bHTML) {
        pCmdUI->SetText(_T("&Omit # Symbol\tCtrl+O"));
    }
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// setup the hyperlinks

	m_link.SetLink(TRUE)
		.SetTextColor(RGB(0,0,255))
		.SetFontUnderline(TRUE)
		.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));

	m_maillink.SetLink(TRUE)
		.SetTextColor(RGB(0,0,255))
		.SetFontUnderline(TRUE)
		.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));
	
	return TRUE;
}

void CHtmlcopDlg::OnExpandDialog() 
{
	m_bExpandedVersion = m_bExpandedVersion?false:true;
	if (m_bExpandedVersion)
		SetStatusBarText(_T("Expanded dialog ON"));
	else
		SetStatusBarText(_T("Expanded dialog OFF"));


	TestForExpand();
}

void CHtmlcopDlg::TestForExpand()
{
	RECT currect;
	GetWindowRect(&currect) ;

	//	smWidth = lgWidth;
	//	smHeight = lgHeight;
	
	if ( !m_bExpandedVersion  ) 
	{
		// use lgWidth and lgHeight
		
		currect.right = currect.left + lgWidth;
		currect.bottom = currect.top + lgHeight;

	//	buttonrect.right += 30;

		m_ExpandDialog.SetWindowText( _T("&<<") ); 
//		MoveWindow(&CCopRect);
		MoveWindow(&currect);
	} else {

		// use smWidth and smHeight

		//CWnd* GetDlgItem( int nID ) const;
		
		CWnd* tmp = GetDlgItem(IDC_MAGE);

		//HWND buttonhand;
		//Wnd::GetDlgItem(IDC_CPreview,&buttonhand);


		currect.right = currect.left + smWidth;
		currect.bottom = currect.top + smHeight;

		MoveWindow(&currect);

		m_ExpandDialog.SetWindowText( _T("&>>") ) ; 
	}
}

void CHtmlcopDlg::OnOptionsMinimizetosystray() 
{
	bMinimizetoTray = bMinimizetoTray?FALSE:TRUE;
}

void CHtmlcopDlg::OnUpdateOptionsMinimizetosystray(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(bMinimizetoTray); 
}

void CHtmlcopDlg::OnOptionsUppercasehex() 
{
    bUppercaseHex = bUppercaseHex?FALSE:TRUE;
	TestForUpperHex();
}

void CHtmlcopDlg::OnUpdateOptionsUppercasehex(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(bUppercaseHex); 
}

void CHtmlcopDlg::TestForUpperHex()
{
	// fixes the current hex value to the correct case

	if (bUppercaseHex)
	{
		// make currenthex uppercase
		m_Hexcolor.MakeUpper();
	} else {
		// use lowercase
		m_Hexcolor.MakeLower();
	}
	UpdateData(false);	// update control
}

void CHtmlcopDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//copmenu.LoadMenu(IDR_COPMENU);	

	CMenu tempMenu;
	tempMenu.LoadMenu(IDR_COPMENU);


	ClientToScreen(&point);
	CMenu *pPopup = tempMenu.GetSubMenu(0);

	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON,
						   point.x, point.y, 
						   this, NULL);
	//SetMenu(pPopup);

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
	
	CDialog::OnRButtonDown(nFlags, point);
}

void CHtmlcopDlg::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// right mouse button came up, watch out for capture

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
	
	CDialog::OnRButtonUp(nFlags, point);
}

void CHtmlcopDlg::ChangeTo1pixelSampling() 
{
	SampleRate = 1;		// set to 1 pixel sampling
	SetStatusBarText(_T("1 pixel sampling ON"));
}

void CHtmlcopDlg::ChangeTo3x3Sampling() 
{
	SampleRate = 3;		// set to 3 by 3 average sampling
	SetStatusBarText(_T("3 by 3 average sampling ON"));
}

void CHtmlcopDlg::ChangeTo5x5Sampling() 
{
	SampleRate = 5;		// set to 5 by 5 average sampling
	SetStatusBarText(_T("5 by 5 average sampling ON"));
}

void CHtmlcopDlg::OnUpdatePopupSampling1pixel(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(SampleRate == 1); 	
}

void CHtmlcopDlg::OnUpdatePopupSampling5by5average(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(SampleRate == 5); 	
}

void CHtmlcopDlg::OnUpdatePopupSampling3by3average(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(SampleRate == 3); 
}

void CHtmlcopDlg::AveragePixelArea(HDC hdc, int* m_Reddec, int* m_Greendec, int* m_Bluedec, CPoint point)
{
	// this function averages a matrix of pixels.  
	// either a 3 by 3 or a 5 by 5 average of pixels.

	int reddec = 0, greendec = 0, bluedec = 0;		// temp variables to add up the values
	int offset = 0, elements = 0, xrel, yrel;
	COLORREF crefxy;

	if (SampleRate == 3)
	{
		offset = 1;
		elements = 9;		// 3x3 - add up and divide by 9

	} else if (SampleRate == 5) {

		offset = 2;
		elements = 25;		// 5x5 - add up and divide by 25
	}

	for (xrel = point.x - offset;
	     xrel <= point.x + offset;
		 xrel ++)
		 {
			 for (yrel = point.y - offset;
				 yrel <= point.y + offset;
				 yrel ++)
				 {
						crefxy=::GetPixel(hdc, xrel, yrel);
		
						reddec += GetRValue(crefxy);
						greendec += GetGValue(crefxy);
					    bluedec += GetBValue(crefxy);
				 }
		 }

	*m_Reddec   = (int) reddec / elements;
	*m_Greendec = (int) greendec / elements;
	*m_Bluedec  = (int) bluedec / elements;
}

void CHtmlcopDlg::OnPopupApplicationExpandeddialog() 
{
	// only the menu calls this functionm
	OnExpandDialog();
}

void CHtmlcopDlg::OnUpdatePopupApplicationExpandeddialog(CCmdUI* pCmdUI) 
{
		pCmdUI->SetCheck(m_bExpandedVersion == FALSE);
}

void CHtmlcopDlg::OnPopupHexmodePowerbuilder() 
{
	SetStatusBarText(_T("PowerBuilder Mode ON"));
	if (!bPowerbuilder) {
		bPowerbuilder = TRUE;
		bHTML = FALSE;
		bDelphi = FALSE;
		bVisualBasic = FALSE;
		bVisualC = FALSE;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnUpdatePopupHexmodePowerbuilder(CCmdUI* pCmdUI) 
{
		pCmdUI->SetRadio(bPowerbuilder);
}

void CHtmlcopDlg::OnPopupModeVisualbasichex() 
{
	SetStatusBarText(_T("Visual Basic Hex Mode ON"));
	if (!bVisualBasic) {
		bPowerbuilder = FALSE;
		bHTML = FALSE;
		bDelphi = FALSE;
		bVisualC = FALSE;
		bVisualBasic = TRUE;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnUpdatePopupModeVisualbasichex(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(bVisualBasic);	
}

void CHtmlcopDlg::OnPopupModeVisualchex() 
{
	SetStatusBarText(_T("Visual C++ Hex Mode ON"));
	if (!bVisualC) {
		bPowerbuilder = FALSE;
		bHTML = FALSE;
		bDelphi = FALSE;
		bVisualBasic = FALSE;
		bVisualC = TRUE;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnUpdatePopupModeVisualchex(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(bVisualC);
}

void CHtmlcopDlg::OnPopupRestore() 
{
	ShowWindow(SW_RESTORE);		// user wants to restore from systray
	bMinimized = false;			// remove the systray icon
	SetupTrayIcon();	 
	SetupTaskBarButton();		// add taskbar button
}

void CHtmlcopDlg::OnPopupExit() 
{
	bMinimized = false;			// user wants to exit color cop
	SetupTrayIcon();			// remove the systray icon
	OnCancel();	
}

void CHtmlcopDlg::SetupStatusBar()
{

	int nTotWide;		// total width of status bar
	
	CRect rect;
   	 this->GetWindowRect(&rect);
	 rect.top = rect.bottom -25;
    	
	BOOL bStatOk = m_StatBar.Create(  CCS_NODIVIDER | WS_CHILD | WS_BORDER | WS_VISIBLE ,rect,this,
        				        IDC_STATUSBAR);
                             
    if (bStatOk == NULL)
	{
         	AfxMessageBox ("Status Bar not created!", NULL, MB_OK );
	}
	
	//
   	// get size of window, use to configure the status bar
    	//
    	
	CRect rWin;
   	this->GetWindowRect(&rWin);
   	nTotWide = rWin.right-rWin.left;
	
	//
	// Make each part 1/4 of the total width of the window.
	//
	int m_Widths[1];

   	
	m_Widths[0] = nTotWide; // / 4;
   	//m_Widths[1] = nTotWide / 2;
   	//m_Widths[2] = nTotWide - m_Widths[0];
   	//m_Widths[3] = -1;
   
	m_StatBar.SetMinHeight(25);
	m_StatBar.SetParts( 1, m_Widths); 

	
	m_StatBar.SetText("Right Click in dialog for a menu", 0, 0);
	
	//
	// now lets put some text, different styles into parts of status bar
	//


	//m_StatBar.SetText("WITHOUT BORDER.",1,SBT_NOBORDERS);
	//m_StatBar.SetText("POPUP.",2,SBT_POPOUT);

 	//
	//	make the last part owner-drawn, add a bitmap
	//	

//	m_StatBar.SetText(NULL,3, SBT_OWNERDRAW);

	//	hBmp is a Global Variable of type HBITMAP 	
//	hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_BITMAP1));


}

void CHtmlcopDlg::SetStatusBarText(LPCTSTR statusText)
{
	m_StatBar.SetText(statusText, 0,0);

}

BOOL CHtmlcopDlg::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// determine which edit control has the focus??

	CWnd* curfocus = GetFocus();	// handle to the window with focus

	if (curfocus == NULL)	// There is nothing with the focus
		return TRUE;		// jump out 

	int offset = 1;					// default

	if (nFlags == MK_CONTROL)		// jump by 5 if control is down
		offset = 5;
	else if (nFlags == MK_SHIFT)	// jump by 2 if shift is down
		offset = 2;

	// if bSnaptoWebsafe is on then incrementing by 1, 5 or 2 won't do any good
	// because it will just snap lower.

	if (bSnaptoWebsafe)		// therefore, increment or decrement by 51
		offset = 51; 

	if (curfocus == GetDlgItem(IDC_RED)) {			// red has focus
		m_Reddec+=zDelta/WHEEL_DELTA * offset;
		m_Reddec = RangeCheck(m_Reddec);

	} else if (curfocus == GetDlgItem(IDC_GREEN)) {	// green has focus
		m_Greendec+=zDelta/WHEEL_DELTA * offset;
		m_Greendec = RangeCheck(m_Greendec);

	} else if (curfocus == GetDlgItem(IDC_BLUE)) {	// blue has focus
		m_Bluedec+=zDelta/WHEEL_DELTA * offset;
		m_Bluedec = RangeCheck(m_Bluedec);

	} else 
		return TRUE;	// jump out if it's not on R, G, or B
		
	

	UpdateData(false);
	OnconvertRGB();

	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

int CHtmlcopDlg::RangeCheck(int icolorval)
{
	if (icolorval > 255)	
		return 255;
	else if (icolorval < 0)
		return 0;
	else 
		return icolorval;
}

void CHtmlcopDlg::OnTimer(UINT nIDEvent) 
{
	//Beep(504,5);
	CDialog::OnTimer(nIDEvent);
}
