---------------------------[ Color Cop v4.0 ]--------------------------

Color Cop v4.0 converts RGB decimal values to RGB Hexadecimal Triplets.
It has a built in color picker, color preview, auto copy to clipboard,
and an eyedropper to choose colors anywhere on the screen.  Color Cop
now has support for Delphi Hex color codes.  Tested on Windows 95/98/NT/2000.

Comments, Suggestions, and Bugs can be emailed to support@datastic.com
If find this program useful please come to my website and sign my guestbook.

Color Cop Website: http://www.datastic.com/tools/colorcop.html



*** FEATURES ***
- Decimal RGB -> RGB Hexadecimal Triplet
- RGB Hexadecimal Triplet -> Decimal RGB
- Eyedropper : Allows you to pick a color from anywhere on the screen.
- Auto Copy RGB Hexadecimal Triplet To Clipboard  
- Custom Color Picker
- On-the-Fly Color Preview
- Remembers settings from last run
- Support for Delphi Hex color codes 
- Random Color Generator
- Reverse Color Option
- Small Size : only 36KB
- Written using Microsoft Visual C++ v6.0
- It's Free!


*** How are these RGB Hexadecimal Triplets used? ***
<html><title>This is a sample</title>
<body bgcolor="#ffffff">This makes the background color WHITE.
<font color="#ffff00">This is YELLOW text.</font>
<table width="100%" bgcolor="#0000ff">
<tr>
<td>This Background is Blue!!</td>
</tr></table>
</body></html>


What's new in version 4.0?

- added menu
- Support For Delphi Hex codes.
- Reverse Color Option
- Random Color Option
- Always on Top now toggleable
- fixed minimize bug. (if you closed older versions while minimized, the next time you ran it, it would be stuck)


*** What is the Remember Settings Feature all about? ***
Basically the next time you start color cop it will be in the same
location that is was in when you last quit.  It will also remember
the last color you selected and if you had auto copy to clipboard
on.  These settings are saved in the directory you ran color cop
from in a file called ColorCop.dat.  If you delete this file the
default settings will be used.

What ColorCop 4.0 Remembers?

- Last Screen Position
- Last Color Selected
- Last mode (Delphi or HTML Hex mode)
- Auto on top and auto copy to clipboard options


*** TROUBLESHOOTING ***
If you have any trouble running Color Cop, try downloading the
statically linked version (it doesn't need mfc42.dll) here:
http://www.datastic.com/tools/colorcop.html
Either that or download the lastest mfc42.dll.


*** REVISION HISTORY ***
v4.0 - 05/17/00 : Added pulldown menus
                : Added Support for Delphi Hex codes
                : Added Reverse Color Option
                : Added Random Color Option
                : Always on Top now toggleable
                : fixed minimize bug. (if you closed older versions
                  while minimized, the next time you ran it, it would be stuck)
                : Still only 36KB!
v3.6 - 02/20/00 : Color Cop can now convert from HEX to RGB
                : Added link to colorcop website in ABOUT
v3.5 - 11/11/99 : Added Eyedropper support
		: made dialog A LOT smaller
		: Added Always on top.(for use with eyedropper)
		: Added Remember Settings for next run - 32KB
v3.0 - 10/1/99  : Changed Fonts back to MS San Serif
		: Fixed the over 255 Bug
		: Enlarged Edit Boxes for oversized fonts - 28KB
v2.2 - 9/24/99  : Added Auto Copy to Clipboard - 28KB
v2.0 - 8/22/99  : Added Color Preview - 14KB
v1.0 - 8/15/99  : Added Custom Color Picker - 13KB

Still need help? or you have a suggestion? Email support@datastic.com

--------------------------------------[ End of File ]------------------