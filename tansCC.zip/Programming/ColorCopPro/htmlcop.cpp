// htmlcop.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "htmlcop.h"
#include "htmlcopDlg.h"
#include <windows.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopApp

BEGIN_MESSAGE_MAP(CHtmlcopApp, CWinApp)
	//{{AFX_MSG_MAP(CHtmlcopApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopApp construction

CHtmlcopApp::CHtmlcopApp()
{}

/////////////////////////////////////////////////////////////////////////////
// The one and only CHtmlcopApp object

CHtmlcopApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopApp initialization

BOOL CHtmlcopApp::InitInstance()
{

#ifdef _AFXDLL
	Enable3dControls();			// shared 
#else
	Enable3dControlsStatic();	// static
#endif
	CHtmlcopDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	
	if (nResponse == IDOK)
	{
		;
	}
	else if (nResponse == IDCANCEL){}
	return FALSE;
}
