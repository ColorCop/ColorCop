// htmlcopDlg.h : header file
//

#if !defined(AFX_HTMLCOPDLG_H__EC2A34E6_4FAA_11D3_81A0_A79013DBA62A__INCLUDED_)
#define AFX_HTMLCOPDLG_H__EC2A34E6_4FAA_11D3_81A0_A79013DBA62A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopDlg dialog

#include "WavTipCtrl.h"		// used to add tooltips to the dialog :)


class CSystemTray;

class CHtmlcopDlg : public CDialog
{
// Construction
public:
	CHtmlcopDlg(CWnd* pParent = NULL);	// standard constructor
	CWavTipCtrl m_tooltip;

// Dialog Data
	//{{AFX_DATA(CHtmlcopDlg)
	enum { IDD = IDD_HTMLCOP_DIALOG };
	CStatic	m_ColorPreview;
	CButton	m_ExpandDialog;
	CStatic	m_Magnifier;
	CStatic	m_EyeLoc;
	int		m_Greendec;
	int		m_Bluedec;
	int		m_Reddec;
	CString	m_Hexcolor;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHtmlcopDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void Serialize(CArchive& ar);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:


	HICON m_hIcon, m_hBlank, m_hEye;
	TCHAR wtitle[16];
	HWND CCopHWND;

	int SampleRate; // stores what sampling rate is going on.

	// Store for snapback from websafe,  unsigned char only takes 1 byte, 0 - 255
	unsigned char m_OldRed, m_OldBlue, m_OldGreen;
	BOOL bOldClrExist;
	
	BOOL bOnTop;			
	BOOL bDelphi;		
	BOOL bHTML;
	BOOL bAutoCopy;
    BOOL bOmitPound;
	BOOL bSnaptoWebsafe;
	BOOL bUppercaseHex;
	BOOL bMinimizetoTray;
	BOOL m_isEyedropping;
	BOOL m_isMagnifying;
	BOOL m_bExpandedVersion;	
	BOOL bMinimized;
	BOOL bPowerbuilder;
	BOOL bVisualBasic;
	BOOL bVisualC;
	
	CStatusBarCtrl m_StatBar;

	int smHeight, smWidth, lgHeight, lgWidth;
	int WinLocX,WinLocY;



	COLORREF CustColorBank[16];
	CMenu copmenu;
	HDC hdc, hdcMem;

	CRect buttonrect;	// color window rect
	CRect magrect;		// magnifyer rect, based off color window rect
	RECT CCopRect, CCopsmRect;

	HBITMAP hBitmap;
	HCURSOR m_hEyeCursor, m_hMagCursor;

	////  systray Internal data
	HICON hIcon_;
	bool bMinimized_;
	CSystemTray* pTrayIcon_;
	int nTrayNotificationMsg_;
	// end

	void CHtmlcopDlg::StopCapture(void);
	void CHtmlcopDlg::DisplayColor();
	void CHtmlcopDlg::ParseHTML(CString inst);
	void CHtmlcopDlg::ParseDelphi(CString inst);
    void CHtmlcopDlg::FigurePound();
	void CHtmlcopDlg::TestForExpand();
	int CHtmlcopDlg::DecimaltoWebsafe(int originalDec);
	void CHtmlcopDlg::TestForUpperHex();
	void CHtmlcopDlg::OnconvertHEX();
	void CHtmlcopDlg::OnconvertRGB();
	void CHtmlcopDlg::OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu);
	void CHtmlcopDlg::UpdateMenu(CMenu* pMenu);
	void CHtmlcopDlg::ToggleOnTop();
	void CHtmlcopDlg::TestForWebsafe();
	void CHtmlcopDlg::SetupTaskBarButton();
	void CHtmlcopDlg::SetupTrayIcon();
	void CHtmlcopDlg::SetupSystemMenu();
	void CHtmlcopDlg::SetupWindowRects();
	bool CHtmlcopDlg::LoadPersistentVariables();
	void CHtmlcopDlg::LoadDefaultSettings();
	void CHtmlcopDlg::AveragePixelArea(HDC hdc, int* m_Reddec, int* m_Greendec, int* m_Bluedec, CPoint point);
	void CHtmlcopDlg::SetupStatusBar();
	void CHtmlcopDlg::SetStatusBarText(LPCTSTR statusText);
	int CHtmlcopDlg::RangeCheck(int icolorval);


	// Generated message map functions
	//{{AFX_MSG(CHtmlcopDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnAbout();
	afx_msg void OnChangeGreen();
	afx_msg void OnChangeBlue();
	afx_msg void OnChangeRed();
	afx_msg void OnColorPick();
	afx_msg void OnCopytoclip();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnChangeHexcolor();
	afx_msg void OnDestroy();
	afx_msg void OnFileExit();
	afx_msg void OnColorReverse();
	afx_msg void OnOptionsAlwaysontop();
	afx_msg void OnUpdateOptionsAlwaysontop(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOptionsDelphimode(CCmdUI* pCmdUI);
	afx_msg void OnOptionsDelphimode();
	afx_msg void OnUpdateOptionsAutocopytoclipboard(CCmdUI* pCmdUI);
	afx_msg void OnOptionsAutocopytoclipboard();
	afx_msg void OnColorRandom();
	afx_msg void OnUpdateViewHtmlhexmode(CCmdUI* pCmdUI);
	afx_msg void OnViewHtmlhexmode();
	afx_msg void OnFileAbout();
	afx_msg void OnColorSnaptowebsafe();
	afx_msg void OnOptionsOmitsymbol();
	afx_msg void OnUpdateOptionsOmitsymbol(CCmdUI* pCmdUI);
	afx_msg void OnExpandDialog();
	afx_msg void OnUpdateColorSnaptowebsafe(CCmdUI* pCmdUI);
	afx_msg void OnOptionsMinimizetosystray();
	afx_msg void OnUpdateOptionsMinimizetosystray(CCmdUI* pCmdUI);
	afx_msg void OnOptionsUppercasehex();
	afx_msg void OnUpdateOptionsUppercasehex(CCmdUI* pCmdUI);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void ChangeTo1pixelSampling();
	afx_msg void OnUpdatePopupSampling1pixel(CCmdUI* pCmdUI);
	afx_msg void ChangeTo3x3Sampling();
	afx_msg void OnUpdatePopupSampling3by3average(CCmdUI* pCmdUI);
	afx_msg void ChangeTo5x5Sampling();
	afx_msg void OnUpdatePopupSampling5by5average(CCmdUI* pCmdUI);
	afx_msg void OnPopupApplicationExpandeddialog();
	afx_msg void OnUpdatePopupApplicationExpandeddialog(CCmdUI* pCmdUI);
	afx_msg void OnPopupHexmodePowerbuilder();
	afx_msg void OnUpdatePopupHexmodePowerbuilder(CCmdUI* pCmdUI);
	afx_msg void OnPopupModeVisualbasichex();
	afx_msg void OnUpdatePopupModeVisualbasichex(CCmdUI* pCmdUI);
	afx_msg void OnPopupModeVisualchex();
	afx_msg void OnUpdatePopupModeVisualchex(CCmdUI* pCmdUI);
	afx_msg void OnPopupRestore();
	afx_msg void OnPopupExit();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLCOPDLG_H__EC2A34E6_4FAA_11D3_81A0_A79013DBA62A__INCLUDED_)
