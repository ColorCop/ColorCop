//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by htmlcop.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HTMLCOP_DIALOG              102
#define IDS_HEXCOLOR_TOOLTIP            102
#define IDS_EYEDROPPER_TOOLTIP          103
#define IDR_MAINFRAME                   128
#define IDC_EYE                         129
#define IDI_BLANK                       130
#define IDI_EYE                         131
#define IDC_HAND                        137
#define IDR_COPMENU                     138
#define IDC_MAGGLASS                    140
#define IDI_MAGGLASS                    141
#define IDB_BITMAP1                     145
#define IDC_CURSOR1                     147
#define IDR_SYSTRAY_MENU                148
#define IDC_CURSOR2                     150
#define IDC_CURSOR3                     151
#define IDM_ALWAYSONTOP                 0x0100
#define IDC_RED                         1000
#define IDC_GREEN                       1001
#define IDC_BLUE                        1002
#define IDC_REDT                        1006
#define IDC_GREENT                      1007
#define IDC_BLUET                       1008
#define IDC_HEXCOLOR                    1009
#define IDC_HEXTEXT                     1010
#define IDC_convert                     1011
#define IDC_About                       1012
#define IDC_ColorPick                   1013
#define IDC_CPreview                    1016
#define IDC_COPYTOCLIP                  1018
#define IDC_EYELOC                      1020
#define IDC_ONTOP                       1021
#define IDC_MINIMIZE                    1025
#define IDC_LINK                        1026
#define IDC_MAILLINK                    1027
#define IDC_MAGE                        1029
#define IDC_MagArea                     1030
#define IDC_EXPAND_DIALOG               1033
#define IDC_MagWindow                   1034
#define IDC_STATUSBAR                   32550
#define ID_FILE_EXIT                    32771
#define ID_OPTIONS_ALWAYSONTOP          32772
#define ID_OPTIONS_DELPHIMODE           32773
#define ID_OPTIONS_AUTOCOPYTOCLIPBOARD  32774
#define ID_COLOR_REVERSE                32775
#define ID_COLOR_RANDOM                 32776
#define ID_VIEW_HTMLHEXMODE             32778
#define ID_FILE_ABOUT                   32779
#define ID_COLOR_SNAPTOWEBSAFE          32780
#define ID_OPTIONS_OMITSYMBOL           32781
#define ID_OPTIONS_UPPERCASEHEX         32783
#define IDS_ALWAYSONTOP                 32784
#define ID_OPTIONS_MINIMIZETOSYSTRAY    32784
#define ID_POPUP_SAMPLING_1PIXEL        32791
#define ID_POPUP_SAMPLING_3BY3AVERAGE   32792
#define ID_POPUP_SAMPLING_5BY5AVERAGE   32793
#define ID_POPUP_APPLICATION_EXPANDEDDIALOG 32795
#define ID_POPUP_HEXMODE_POWERBUILDER   32796
#define ID_POPUP_MODE_VISUALBASICHEX    32797
#define ID_POPUP_MODE_VISUALCHEX        32798
#define ID_POPUP_RESTORE                32799
#define ID_POPUP_EXIT                   32800
#define IDS_MAG_WINDOW                  32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
