/************************************************************************************
 *                                                                                  *
 * htmlcopDlg.cpp :: Color Cop - by Jay Prall - Jay@datastic.com                    *
 *                                                                                  *
 * note: all of the files are called Htmlcop, because that's what I originally      *
 *       called it when I first started writing color cop in August of 1999         *
 *                                                                                  *
 * Please do not distribute this file.                                              *
 ************************************************************************************/

#include "stdafx.h"
#include "htmlcop.h"
#include "htmlcopDlg.h"
#include "Label.h"			// used for the Links in the AboutDlg

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CLabel	m_maillink;
	CLabel	m_link;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}


void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_MAILLINK, m_maillink);
	DDX_Control(pDX, IDC_LINK, m_link);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopDlg dialog

CHtmlcopDlg::CHtmlcopDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHtmlcopDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHtmlcopDlg)
	m_Greendec = 0;
	m_Bluedec = 0;
	m_Reddec = 0;
	m_Hexcolor = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHtmlcopDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHtmlcopDlg)
	DDX_Control(pDX, IDC_EXPAND_DIALOG, m_ExpandDialog);
	DDX_Control(pDX, IDC_MAGE, m_Magnifier);
	DDX_Control(pDX, IDC_EYELOC, m_EyeLoc);
	DDX_Text(pDX, IDC_GREEN, m_Greendec);
	DDX_Text(pDX, IDC_BLUE, m_Bluedec);
	DDX_Text(pDX, IDC_RED, m_Reddec);
	DDX_Text(pDX, IDC_HEXCOLOR, m_Hexcolor);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHtmlcopDlg, CDialog)
	//{{AFX_MSG_MAP(CHtmlcopDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_About, OnAbout)
	ON_EN_CHANGE(IDC_GREEN, OnChangeGreen)
	ON_EN_CHANGE(IDC_BLUE, OnChangeBlue)
	ON_EN_CHANGE(IDC_RED, OnChangeRed)
	ON_BN_CLICKED(IDC_ColorPick, OnColorPick)
	ON_BN_CLICKED(IDC_COPYTOCLIP, OnCopytoclip)
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(IDC_HEXCOLOR, OnChangeHexcolor)
	ON_WM_DESTROY()
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	ON_COMMAND(ID_COLOR_REVERSE, OnColorReverse)
	ON_COMMAND(ID_OPTIONS_ALWAYSONTOP, OnOptionsAlwaysontop)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_ALWAYSONTOP, OnUpdateOptionsAlwaysontop)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_DELPHIMODE, OnUpdateOptionsDelphimode)
	ON_COMMAND(ID_OPTIONS_DELPHIMODE, OnOptionsDelphimode)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_AUTOCOPYTOCLIPBOARD, OnUpdateOptionsAutocopytoclipboard)
	ON_COMMAND(ID_OPTIONS_AUTOCOPYTOCLIPBOARD, OnOptionsAutocopytoclipboard)
	ON_COMMAND(ID_COLOR_RANDOM, OnColorRandom)
	ON_UPDATE_COMMAND_UI(ID_VIEW_HTMLHEXMODE, OnUpdateViewHtmlhexmode)
	ON_COMMAND(ID_VIEW_HTMLHEXMODE, OnViewHtmlhexmode)
	ON_COMMAND(ID_FILE_ABOUT, OnFileAbout)
	ON_COMMAND(ID_COLOR_SNAPTOWEBSAFE, OnColorSnaptowebsafe)
	ON_COMMAND(ID_OPTIONS_OMITSYMBOL, OnOptionsOmitsymbol)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_OMITSYMBOL, OnUpdateOptionsOmitsymbol)
	ON_BN_CLICKED(IDC_EXPAND_DIALOG, OnExpandDialog)
	ON_UPDATE_COMMAND_UI(ID_COLOR_SNAPTOWEBSAFE, OnUpdateColorSnaptowebsafe)
	ON_COMMAND(ID_OPTIONS_MINIMIZETOSYSTRAY, OnOptionsMinimizetosystray)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_MINIMIZETOSYSTRAY, OnUpdateOptionsMinimizetosystray)
	ON_COMMAND(ID_OPTIONS_UPPERCASEHEX, OnOptionsUppercasehex)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_UPPERCASEHEX, OnUpdateOptionsUppercasehex)
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_POPUP_SAMPLING_1PIXEL, OnPopupSampling1pixel)
	ON_UPDATE_COMMAND_UI(ID_POPUP_SAMPLING_1PIXEL, OnUpdatePopupSampling1pixel)
	ON_WM_QUERYDRAGICON()
	ON_WM_INITMENUPOPUP()
	ON_COMMAND(ID_POPUP_SAMPLING_3BY3AVERAGE, OnPopupSampling3by3average)
	ON_UPDATE_COMMAND_UI(ID_POPUP_SAMPLING_3BY3AVERAGE, OnUpdatePopupSampling3by3average)
	ON_COMMAND(ID_POPUP_SAMPLING_5BY5AVERAGE, OnPopupSampling5by5average)
	ON_UPDATE_COMMAND_UI(ID_POPUP_SAMPLING_5BY5AVERAGE, OnUpdatePopupSampling5by5average)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlcopDlg message handlers

BOOL CHtmlcopDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	SetupSystemMenu();			// add about and always on top to the system menu

//	copmenu.LoadMenu(IDR_COPMENU);

	//SetMenu(&copmenu);

	bool FoundDatFile = LoadPersistentVariables();
	
	if (!FoundDatFile)
	{
		LoadDefaultSettings();	// because there was no settings file
 
	} else {
	
		// We have some settings... lets apply them.
		//if (!m_bExpandedVersion) 
		//	OnExpandDialog();
		//	TestForExpand();
	}
	ToggleOnTop(); //make always on top, unless save file said not to

	
	EnableToolTips(true);	// Enable tool tips, even though they aren't working yet
	
	//application variables
	bOldClrExist = m_isEyedropping = m_isMagnifying = false;
	m_OldRed = m_OldBlue = m_OldGreen = 0;

	CCopHWND=::GetForegroundWindow();

	SetIcon(m_hIcon, FALSE);	// small icon
    SetIcon(m_hIcon, TRUE);		// big icon

	SetupWindowRects();

	// PreLoad Cursors
	CWinApp* pApp = AfxGetApp();
	ASSERT(pApp);
	if (pApp)
	{
		VERIFY(m_hEyeCursor = pApp->LoadCursor(IDC_EYE));
		VERIFY(m_hMagCursor = pApp->LoadCursor(IDC_MAGGLASS));
		VERIFY(m_hBlank = AfxGetApp()->LoadIcon(IDI_BLANK));

	}
	OnconvertRGB();

	GetDlgItem(IDC_RED)->SetFocus();	// set the focus to the Red edit control

	return FALSE;  
}

void CHtmlcopDlg::SetupSystemMenu()
{

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
    ASSERT(IDM_ALWAYSONTOP < 0xF000);

	//get the handle to the control menu
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		// Load string and add 'about cc' to the system menu
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())	
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}

		 // Load stringon top to system menu
		CString strAlwaysMenu;
		strAlwaysMenu.LoadString(IDS_ALWAYSONTOP);
		if (!strAlwaysMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_STRING, IDM_ALWAYSONTOP, strAlwaysMenu);
		}

		// disable maxmize in the system menu
		pSysMenu->EnableMenuItem(SC_MAXIMIZE, MF_BYCOMMAND | MF_GRAYED );

		// disable sizing in the system menu
		pSysMenu->EnableMenuItem(SC_SIZE, MF_BYCOMMAND | MF_GRAYED );
	}
}

bool CHtmlcopDlg::LoadPersistentVariables()
{
	bool retval = false;

	TCHAR szPath[MAX_PATH];
	if( 0 != GetModuleFileName(AfxGetInstanceHandle(),szPath,sizeof(szPath)) )
	{
		LPTSTR pName = _tcsrchr(szPath, '\\');
		if(!pName)
			pName = szPath;
		_tcscpy(pName, "\\ColorCop5.dat");
	}
	try
	 {
		CFile file;
		if( file.Open(szPath, CFile::modeRead) )
		{
			CArchive ar(&file, CArchive::load);
			Serialize(ar);
			

			//Minimize Close Bug,

			/*

			This is to check to see if the location of colorcop was stored
			as minimized.  programs aren't actually minimized, they seem to 
			just be moved off the screen.  The problem is different 
			operating systems handle this differently:

			Win NT/2000/Me - moves the window to -32000, -32000
			Win98 / 95 - moves the window to 3000,3000

			The follow if checks to see if this is the case, if it is -
			the program is repositioned.
            */

			if (WinLocX < 0 || WinLocY < 0  /*negative*/ 
				|| WinLocX  == 3000 || WinLocY == 3000)
			{
			
				// DEBUG - remove this
			//	char a[90];
			//	sprintf(a,"ColorCop has been moved back onto the screen from %d, %d", WinLocX, WinLocY);
			//	AfxMessageBox(a);

			
				WinLocX = 200;	// default position..  quickfix
				WinLocY = 200;
			}

			SetWindowPos(&wndTopMost,WinLocX,WinLocY, 0, 0, SWP_NOSIZE | WS_EX_TOPMOST);
			
			retval = true;	// if we get this far, everything is cool
		
		}
	}
	catch(CFileException*)
	{
		AfxMessageBox("Trouble loading file");
	}

	return retval;
}


void CHtmlcopDlg::SetupWindowRects()
{
	// setup color window rect based on the Static box
	HWND buttonhand;
	CWnd::GetDlgItem(IDC_CPreview,&buttonhand);
	::GetWindowRect(buttonhand,&buttonrect);
	CWnd::ScreenToClient(&buttonrect);
	
	HWND maghand;
	CWnd::GetDlgItem(IDC_MagWindow,&maghand);
	::GetWindowRect(maghand, &magrect);
	CWnd::ScreenToClient(magrect);

	RECT exprect;
	HWND expandbutton;
	CWnd::GetDlgItem(IDC_EXPAND_DIALOG, &expandbutton);
	::GetWindowRect(expandbutton, &exprect);
	CWnd::ScreenToClient(&exprect);

	// Get a rect of the entire window.
	CWnd::GetWindowRect(&CCopRect);
//	CWnd::ScreenToClient(&CCopRect);
	CCopsmRect = CCopRect;			// copy rect


	// largeWidth
	char al[99];
	//sprintf(al," width = %d", CCopRect.right - CCopRect.left);

	// largeHeight
	//AfxMessageBox(al);

	//sprintf(al," height = %d", CCopRect.bottom - CCopRect.top);
	//AfxMessageBox(al);

	//small width
	sprintf(al," small width = %d", CCopRect.right/*exprect.right*/);
	AfxMessageBox(al);



//	exprect


//	CCopsmRect.SetRect(CCopRect.TopLeft().x, CCopRect.TopLeft().y,
//		               exprect.BottomRight().x, exprect.BottomRight().y); 

	CCopsmRect.right-=40;
		CCopsmRect.bottom-=115;

	//buttonrect = CCopsmRect;
	//MoveWindow( &CCopsmRect );
//	TestForExpand();
}

void CHtmlcopDlg::LoadDefaultSettings()
{
		// This function is called when we can't find a .DAT file
		// with the persistent variables, or it was an old dat file

		// OK - better set the default settings and custom colors

		m_Reddec = m_Bluedec = m_Greendec = 0;

		bDelphi=0;	    //View
		bHTML=1;	    //View  - default to HTML mode

		bOnTop=1;	    //Options	- default always on top
		bAutoCopy=1;    //Options	- default autocopy
		bOmitPound=0;   //Options
		bUppercaseHex=1;//use uppercase hex by default 
		
		bSnaptoWebsafe=0;
		bMinimizetoTray = 0;	// normal minimize by default

		m_bExpandedVersion = false;

		SampleRate = 1;   // default to 1 pixel sampling, not 3x3 or 5x5

		// set all custom color blocks to white
		for(int initcolor = 0; initcolor < 16; initcolor++)
			CustColorBank[initcolor] = 0x00FFFFFF;  
		            //C++ explicit hex 0x00bbggrr 

}

void CHtmlcopDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	// this is function is called when the user selects an item 
	// from the system menu. (right clicking on the minimized program,
	// or right clicking on the system icon
	
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	} else if ((nID & 0xFFF0) == IDM_ALWAYSONTOP)
	{
		bOnTop=bOnTop?0:1;
		ToggleOnTop();
	
		CMenu* pSysMenu = GetSystemMenu(FALSE);
		if (pSysMenu != NULL)
		{
			if (bOnTop) 
			{
				// check the menu item
				pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_CHECKED);
			} else {
				pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_UNCHECKED);
				// uncheck the item
			}
		}
	}
	else
	{
		BOOL bOldMin = bMinimized;	// remember previous state

		if (nID == SC_MINIMIZE) {
			bMinimized = true;
		} else if (nID == SC_RESTORE) {
			bMinimized = false;
		}

		CDialog::OnSysCommand(nID, lParam);

		if (bOldMin != bMinimized)
		{
			SetupTrayIcon();
			SetupTaskBarButton();

		}
	}

}

void CHtmlcopDlg::SetupTaskBarButton()
{
	if ((bMinimized) && (bMinimizetoTray != 0)) 
	{
		//ShowWindow(SW_HIDE);
		AfxMessageBox("I wanna hide");

	}
	else {
		ShowWindow(SW_SHOW);
	}

}

void CHtmlcopDlg::SetupTrayIcon()
{
	if ((bMinimized) && (bMinimizetoTray != 0)) 
	{
	//	ShowWindow(SW_HIDE);
		//show tray icon
	}
	else {
	//	ShowWindow(SW_SHOW);
		// remove try icon
	}
}

void CHtmlcopDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); 
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();

		DisplayColor();	// keep the color window showing

		CDC *pDC=GetDC();

        if (hBitmap)
          {
			hdc = ::GetDC(CCopHWND);   

			hdcMem = ::CreateCompatibleDC (hdc);
            ::SelectObject (hdcMem, hBitmap) ;

			// gets info about the bitmap.. might not need this
           //GetObject (hBitmap, sizeof (BITMAP), NULL/*(PSTR) &bm*/) ;

               ::SetStretchBltMode (hdc, COLORONCOLOR) ;
		   
/*               ::StretchBlt (hdc, 
				             buttonrect.TopLeft().x + 3, buttonrect.TopLeft().y + 175, // upper left dest
				             buttonrect.Width(), buttonrect.Height(),  // width of dest rect
                             hdcMem,  // source dc
							 0, 0,	  // upper left source
							 18, 15,  // W x H of source
							 SRCCOPY);// mode
*/
/*
win32 stretchblt

BOOL StretchBlt(
  HDC hdcDest,      // handle to destination device context
  int nXOriginDest, // x-coordinate of upper-left corner of dest. rectangle
  int nYOriginDest, // y-coordinate of upper-left corner of dest. rectangle
  int nWidthDest,   // width of destination rectangle
  int nHeightDest,  // height of destination rectangle
  HDC hdcSrc,       // handle to source device context
  int nXOriginSrc,  // x-coordinate of upper-left corner of source rectangle
  int nYOriginSrc,  // y-coordinate of upper-left corner of source rectangle
  int nWidthSrc,    // width of source rectangle
  int nHeightSrc,   // height of source rectangle
  DWORD dwRop       // raster operation code
);
 */
			 //  CDC* tmpDC;
			 //  CBitmap tmpBitmap;

			//   tmpBitmap.FromHandle(hBitmap);

			 //  if (hBitmap == tmpBitmap.HBITMAP()) 
		//			AfxMessageBox("attached correctly");
			//   tmpBitmap.LoadBitmap(IDB_BITMAP1);

			   //tmpDC->CreateCompatibleDC(NULL);
			  // tmpDC->SelectObject(tmpBitmap);

		//	pDC->BitBlt(0,0, 10, 10, tmpDC, 0, 0, SRCCOPY);

			   // the StretchBlt function copies a bitmap from a source rectangle into a destination rectangle
			   ::StretchBlt (hdc, 
				             magrect.TopLeft().x, magrect.TopLeft().y , // upper left dest
				             magrect.Width(), magrect.Height(),  // width of dest rect
                             hdcMem,  // source dc
							 0, 0,	  // upper left source
							 18, 15,  // W x H of source
							 SRCCOPY);// mode

			//	Beep(400,40);

		/*	   pDC->StretchBlt(magrect.TopLeft().x, magrect.TopLeft().y,
				               magrect.Width(), magrect.Height(),
							   tmpDC,
							   0,0,
							   18, 15,
							   SRCCOPY);
		*/
				::DeleteDC (hdcMem);	// temporary DC
				::ReleaseDC (::GetForegroundWindow(), hdc);
          }

		pDC->DrawEdge(magrect, EDGE_SUNKEN, BF_RECT);
		ReleaseDC(pDC);
	}
}

void CHtmlcopDlg::OnconvertRGB() 
{
    TestForWebsafe();	// before conversion

	if (bHTML)
	{
		m_Hexcolor.Format("#%.2x%.2x%.2x",m_Reddec,m_Greendec,m_Bluedec);
	}
	else // in Delphi Hex Mode
	{
		m_Hexcolor.Format("$00%.2x%.2x%.2x",m_Bluedec,m_Greendec,m_Reddec);
	}

	TestForUpperHex();	// after conversion
    

    if (bOmitPound && bHTML) {
        if (m_Hexcolor.Left(1) == '#') { m_Hexcolor.Delete(0); }
    }
    else if (bOmitPound && bDelphi) {
        if (m_Hexcolor.Left(1) == '$') { m_Hexcolor.Delete(0); }
    }

	UpdateData(false); //send m_Hexcolor back to edit control
	
	OnCopytoclip();
	DisplayColor();
}

void CHtmlcopDlg::OnconvertHEX() 
{
	TestForWebsafe();		// before

	if (bHTML)
	{	
		if ((m_Greendec==0) && (m_Bluedec==0) && (m_Reddec!=0)) 
		{
			m_Hexcolor.Format("#%.2x0000",m_Reddec);
		}
		else if ((m_Greendec!=0) && (m_Bluedec==0) && (m_Reddec!=0)) 
		{
			m_Hexcolor.Format("#%.2x%.2x00", m_Reddec, m_Greendec);
		}
		else 
		{
			m_Hexcolor.Format("#%.2x%.2x%.2x", m_Reddec, m_Greendec, m_Bluedec);
		}
	}
	else
		m_Hexcolor.Format("$00%.2x%.2x%.2x", m_Bluedec, m_Greendec, m_Reddec);

    if (bOmitPound && bHTML) {
        if (m_Hexcolor.Left(1) == '#') 
			m_Hexcolor.Delete(0);
    }
    else if (bOmitPound && bDelphi) {
        if (m_Hexcolor.Left(1) == '$') 
			m_Hexcolor.Delete(0);
    }
	
    DisplayColor();
	OnCopytoclip();
}



void CHtmlcopDlg::DisplayColor()
{	
	CDC *pDC = GetDC();

	CBrush thecolor(RGB(m_Reddec,m_Greendec,m_Bluedec));	// create the brush to paint with

	pDC->FillRect(buttonrect, &thecolor);
	
	if (bSnaptoWebsafe)
	{
	//	pDC->SetBkColor(RGB(m_Reddec,m_Greendec,m_Bluedec));
	//	pDC->SetTextColor(RGB(abs(m_Reddec -255),abs(m_Greendec-255),abs(m_Bluedec-255)));
	//	pDC->SetTextAlign(TA_CENTER | TA_BOTTOM);
	// 	buttonrect.top -= 10;
	/*	buttonrect.SetRect(buttonrect.TopLeft().x+10,
			buttonrect.TopLeft().y+10,
			buttonrect.BottomRight().x-10,
			buttonrect.BottomRight().y-10);
*/
		//AfxMessageBox("d");
	//	pDC->DrawText(_T("\n\n Websafe"), 10, buttonrect, NULL );
	}
	pDC->DrawEdge(buttonrect, EDGE_SUNKEN, BF_RECT);

	//pDC->LineTo(magrect.TopLeft().x, magrect.TopLeft().y);
   // pDC->FillRect(magrect, &thecolor);

	ReleaseDC(pDC);
	return;
}

void CHtmlcopDlg::OnAbout() 
{
	CAboutDlg dlg; 
	dlg.DoModal();
}

void CHtmlcopDlg::OnChangeGreen() 
{
	UpdateData(true); 
	if (m_Greendec > 255)
	{ 
		m_Greendec = 255;
		UpdateData(false);
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnChangeBlue() 
{
	UpdateData(); 
	if (m_Bluedec>255)
	{ 
		m_Bluedec=255;
		UpdateData(false);
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnChangeRed() 
{
	UpdateData();
	if (m_Reddec>255)
	{ 
		m_Reddec=255;
		UpdateData(false);
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnColorPick() 
{
	// set up the common windows color dialog
	COLORREF temp;
	CColorDialog dlgcolor;
	dlgcolor.m_cc.rgbResult = RGB(m_Reddec,m_Greendec,m_Bluedec);
	dlgcolor.m_cc.Flags = CC_RGBINIT | CC_FULLOPEN;
	dlgcolor.m_cc.lpCustColors = CustColorBank;		// load up the Custom colors

	// show the dialog
	if (dlgcolor.DoModal() == IDOK)
	{
		temp=dlgcolor.GetColor();

		m_Reddec=GetRValue(temp);
		m_Greendec=GetGValue(temp);
		m_Bluedec=GetBValue(temp);

		UpdateData(false);
		OnconvertRGB();
	}
	// else if they didn't hit OK, do nothing

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();

}

void CHtmlcopDlg::OnCopytoclip() 
{
	// win32 api calls
	HWND CCopHWND=::GetForegroundWindow();		// get a handle to the app window
	
	if(bAutoCopy == 1)	// the option to auto copy to the clipboard is ON
	{
		if(::OpenClipboard(CCopHWND))
		{
			HGLOBAL clipbuffer;
  			char * buffer;
			::EmptyClipboard();
			clipbuffer=::GlobalAlloc(GMEM_DDESHARE, m_Hexcolor.GetLength()+1);
			buffer = (char *) GlobalLock(clipbuffer);
			strcpy(buffer, LPCSTR(m_Hexcolor));
			::GlobalUnlock(clipbuffer);
			::SetClipboardData(CF_TEXT,clipbuffer);
			::CloseClipboard();
		}
	}
	return;		
}

void CHtmlcopDlg::StopCapture()
{
/*	if (hBitmap)	// if an old magni-bitmap exists, delete it
    {
		DeleteObject (hBitmap) ;
        hBitmap = NULL ;
    }*/

	// we don't want to capture anymore, they let up the left mouse button, or hit ESC
	
	m_isMagnifying = m_isEyedropping = FALSE;
	SetWindowText(_T("Color Cop BETA"));
	ReleaseCapture();
	
	// put the icons back in their holders
	m_EyeLoc.SetIcon(m_hEyeCursor);
	m_Magnifier.SetIcon(m_hMagCursor);
	SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));	// put standard cursor back on
	return;
}

void CHtmlcopDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// the left mouse button was pressed
	// OK - lets see if it was pressed over the eyedropper or magnifier

	CWnd* pWnd = ChildWindowFromPoint(point);
	if (pWnd && pWnd->GetSafeHwnd() == m_EyeLoc.GetSafeHwnd())
	{
		m_isEyedropping = true;
		SetCapture();
		m_EyeLoc.SetIcon(m_hBlank);
		SetCursor(m_hEyeCursor);
	} else if (pWnd && pWnd->GetSafeHwnd() == m_Magnifier.GetSafeHwnd())
	{
		SetCursor(m_hMagCursor);
		m_isMagnifying = true;
		SetCapture();
		m_Magnifier.SetIcon(m_hBlank);

	}

	CDialog::OnLButtonDown(nFlags, point);
}

void CHtmlcopDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// left mouse buttom was released
	// OK - no more eyedropping or magnifying

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
	
	CDialog::OnLButtonUp(nFlags, point);	
}

void CHtmlcopDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// code common to eyedropping and magnifiying
	if (m_isEyedropping || m_isMagnifying)	
	{

		ClientToScreen(&point); //use screen coordinates..
		// show current x, y location on titlebar
		sprintf(wtitle," %d, %d", point.x,point.y);
		SetWindowText(wtitle);
	}

	if (m_isEyedropping)	// is the eyedropper in use?
	{
		COLORREF crefxy;
		hdc = ::GetDC(NULL);

		if (SampleRate == 1)	// only sample one pixel.
		{
			crefxy=::GetPixel(hdc, point.x, point.y);
		
			m_Reddec   = GetRValue(crefxy);
			m_Greendec = GetGValue(crefxy);
			m_Bluedec  = GetBValue(crefxy);
		} else {
			// the user wants to sample a 3x3 or a 5x5 average of pixels.
			AveragePixelArea(hdc, &m_Reddec, &m_Greendec, &m_Bluedec, point);
		}
		::ReleaseDC (::GetForegroundWindow(), hdc);


		UpdateData(false);	// update vars
		OnconvertRGB();

	} else if (m_isMagnifying)		// or are we magnifiying??
	{
		if (hBitmap)	// delete the old bitmap, right before we get a new one
        {
			DeleteObject (hBitmap) ;
            hBitmap = NULL ;
        }

		hdc = ::GetDC(NULL);
		
        hdcMem = ::CreateCompatibleDC(hdc);
		hBitmap = CreateCompatibleBitmap(hdc, 18, 15);

		::SelectObject(hdcMem, hBitmap);

        ::StretchBlt (hdcMem,			// destination DC
			          0, 0,				// destination upper left
					  18, 15,			// width of destination
                      hdc,				// source DC
					  point.x, point.y, // upper left of source
					  18, 15,			// width of source
    				  SRCCOPY);			// raster mode
		
        ::DeleteDC (hdcMem);
		::ReleaseDC (::GetForegroundWindow(), hdc);

		InvalidateRect(NULL, false); // go redraw... but don't erase or it will flicker

	}
	CDialog::OnMouseMove(nFlags, point);
}


BOOL CHtmlcopDlg::PreTranslateMessage(MSG* pMsg) 
{	
	/************************************************
	 * ESC key Check
     * - hitting the escape key, should only stop the 
	 *   eyedropper or magnifing glass and should not 
	 *   exit the app
     ************************************************/

	if (pMsg->message == WM_KEYDOWN)
		if (pMsg->wParam == VK_ESCAPE) 
		{
			if (m_isEyedropping || m_isMagnifying)		// dropper or magnifier in use
				StopCapture();
					
			return TRUE;
		}
	
	// escape wasn't pressed

	// now lets check control keys
	if (pMsg->message == WM_KEYDOWN)
		if (GetAsyncKeyState(VK_CONTROL) < 0 )
			if (pMsg->wParam == 65) // ('A'). 
				OnColorReverse();

	return CDialog::PreTranslateMessage(pMsg);
}



void CHtmlcopDlg::OnChangeHexcolor() 
{
	// the user is typing in the hex edit control
	// or they pasted a hex code.  
	// OK - parse out the RGB values and convert
	
	int hexrange,offset;
	
	UpdateData(1);	// save from control to m_Hexcolor
	int hexsize=0;
	hexsize=m_Hexcolor.GetLength();

	if (bHTML)
	{
		  
		if (m_Hexcolor.Left(1) =='#') 
		{	 
			hexrange=5;
			offset=1;
		}
		else
		{
			hexrange=6;
	 		offset=0;
		}

		while (hexsize>hexrange)
		{
			//AfxMessageBox ("you went too far");
			m_Hexcolor.Delete(6+offset);
			hexsize--;
		}
		m_Reddec=m_Greendec=m_Bluedec=0;
		ParseHTML(m_Hexcolor);

	}
	else //Delphi hex change
	{
		if (m_Hexcolor.Left(1) =='$') 
		{	 
			hexrange=7;
			offset=1;
		}
		else
		{
			hexrange=8;
	 		offset=0;
		}
		
		while (hexsize>hexrange)
		{
			//AfxMessageBox ("you went too far");
			m_Hexcolor.Delete(8+offset);
			hexsize--;
		}
		m_Reddec=m_Greendec=m_Bluedec=0;
		ParseDelphi(m_Hexcolor);
	}
}


void CHtmlcopDlg::ParseDelphi(CString inst)
{
	// they are typing in delphi hex codes
	// determine the RGB values

	int strLen=inst.GetLength();

	if (strLen < 3)	
	{		
		m_Reddec=m_Greendec=m_Bluedec=0;
		UpdateData(false); 
		return;		
	}

	if (inst.Left(1)=='$') inst.Delete(0);
	inst.Delete(0);
	inst.Delete(0);
	m_Bluedec = strtoul( inst.Left(2), NULL, 16);
    inst.Delete(0);
	inst.Delete(0);
	m_Greendec = strtoul( inst.Left(2), NULL, 16);
	inst.Delete(0);
	inst.Delete(0);
	m_Reddec = strtoul( inst.Left(2), NULL, 16);

	UpdateData(0);

	OnconvertHEX();
	return;
}


void CHtmlcopDlg::ParseHTML(CString inst)
{
	// the user is typing in HTML hex codes
	// get the RGB values

	if (inst.Left(1) == '#')	
		inst.Delete(0);  

	int strLen = inst.GetLength();

	if (strLen < 2)	
		return;

	m_Reddec = strtoul( inst.Left(2), NULL, 16);

	inst.Delete(0);
	inst.Delete(0);
	m_Greendec = strtoul( inst.Left(2), NULL, 16);
	inst.Delete(0);
	inst.Delete(0);
	m_Bluedec = strtoul( inst.Left(2), NULL, 16);
	UpdateData(0);

	OnconvertHEX();
	return;
}


void CHtmlcopDlg::OnDestroy() 
{
	// The app is about to close, save the variables

	CDialog::OnDestroy();
	
	tagRECT *winSize = new tagRECT;
	GetWindowRect(winSize);
	WinLocX = winSize->left;		// Store x,y
	WinLocY = winSize->top;		// in variables
	

	TCHAR szPath[MAX_PATH];
	if(0!=GetModuleFileName(AfxGetInstanceHandle(),szPath,sizeof(szPath)))
	{
		LPTSTR pName = _tcsrchr(szPath, '\\');
		if(!pName)
			pName = szPath;
		_tcscpy(pName,"\\ColorCop5.dat");
	}
	try	// to serialize the variables
	{
		CFile file;
		if(file.Open(szPath,CFile::modeWrite|CFile::modeCreate))
		{
		CArchive ar(&file, CArchive::store);
		Serialize(ar);
		}
	}
	catch(CFileException*)
	{
		//something bad happened, we couldn't save the variables..
		AfxMessageBox("There was an error");
	}


}

void CHtmlcopDlg::Serialize(CArchive& ar) 
{

	// persistent variables

	if (ar.IsStoring())
	{	// store variables to file
		try
		{
			ar << m_Reddec;
			ar << m_Greendec;
			ar << m_Bluedec;
			ar << bAutoCopy;
			ar << bOmitPound;
			ar << bOnTop;
			ar << bDelphi;
			ar << bHTML;
			ar << WinLocX;
			ar << WinLocY;
			for (int j = 0; j<16; j++)		//save custom color values from array
				ar << CustColorBank[j];
			ar << m_bExpandedVersion;
			ar << bSnaptoWebsafe;
			ar << bUppercaseHex;
			ar << bMinimizetoTray;
			ar << SampleRate;

		} catch (CArchiveException*) {
			AfxMessageBox(_T("Error writing to colorcop.dat"));
		}
	}
	else
	{	// load variables from file
		try
		{
			ar >> m_Reddec;
			ar >> m_Greendec;
			ar >> m_Bluedec;
			ar >> bAutoCopy;
			ar >> bOmitPound;
			ar >> bOnTop;
			ar >> bDelphi;
			ar >> bHTML;
			ar >> WinLocX;
			ar >> WinLocY;
			for (int j = 0; j<16; j++)		//load custom color values to array
				ar >> CustColorBank[j];
			ar >> m_bExpandedVersion;
			ar >> bSnaptoWebsafe;
			ar >> bUppercaseHex;
			ar >> bMinimizetoTray;
			ar >> SampleRate;
	
		} catch (CArchiveException*) {
			// oops... we've got trouble - let them know
			// This will happen when using an old .DAT file
			// which doesn't have all the variables saved.
			// it could also happen when a user tampers with the binary
			// colorcop.dat file

			AfxMessageBox(_T("Error: You were either using an older version of ColorCop.dat, or it has been tampered with.\nDefault settings will be used."));
			LoadDefaultSettings();
		}
	}
}


void CHtmlcopDlg::OnFileExit() 
{	
	// the user wants to exit from the file menu
	OnDestroy();
	exit(1);	
}


void CHtmlcopDlg::OnColorReverse() 
{
	// Reverse the current colors.
	// ABS (current decimal value - 255)  then update

	m_Reddec=abs(m_Reddec-255);
	m_Greendec=abs(m_Greendec-255);
	m_Bluedec=abs(m_Bluedec-255);
	UpdateData(false);
	OnconvertRGB();
}


void CHtmlcopDlg::OnOptionsAlwaysontop() 
{
	bOnTop=bOnTop?0:1;
	ToggleOnTop();
}


void CHtmlcopDlg::ToggleOnTop()
{
	if (bOnTop) // Make Always on Top
	{
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | WS_EX_TOPMOST);
	}
	else		// Not always on top, NORMAL
	{
		::SetWindowPos(GetSafeHwnd(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}

	// Make sure the checkbox for always on top on the system menu
	// is the same as the checkbox in the dialog menu
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		if (bOnTop) 
			pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_CHECKED);		// check the menu item
		else 
			pSysMenu->CheckMenuItem(IDM_ALWAYSONTOP, MF_UNCHECKED);		// uncheck the item
	}


}


void CHtmlcopDlg::OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu) 
{        
	// this function is called when the top level 
	// menu items are selected.
	UpdateMenu(pMenu);
}

void CHtmlcopDlg::UpdateMenu(CMenu* pMenu)
{
	// this function loops through each menu item and updates the checkboxes and radio buttons

	CCmdUI cmdUI;
	for (UINT n = 0; n < pMenu->GetMenuItemCount(); ++n)
	{
		CMenu* pSubMenu = pMenu->GetSubMenu(n);
        if (pSubMenu == NULL)
        {
			cmdUI.m_nIndexMax = pMenu->GetMenuItemCount();
            for (UINT i = 0; i < cmdUI.m_nIndexMax;++i)
            {
				cmdUI.m_nIndex = i;
                cmdUI.m_nID = pMenu->GetMenuItemID(i);
                cmdUI.m_pMenu = pMenu;
                cmdUI.DoUpdate(this, FALSE);
            }
        }
    }
}

void CHtmlcopDlg::OnUpdateOptionsDelphimode(CCmdUI* pCmdUI)          
{   
	pCmdUI->SetRadio(bDelphi==1);   
}

void CHtmlcopDlg::OnUpdateViewHtmlhexmode(CCmdUI* pCmdUI)            
{   
	pCmdUI->SetRadio(bHTML==1);     
}

void CHtmlcopDlg::OnUpdateOptionsAutocopytoclipboard(CCmdUI* pCmdUI) 
{   
	pCmdUI->SetCheck(bAutoCopy==1); 
}

void CHtmlcopDlg::OnUpdateOptionsAlwaysontop(CCmdUI* pCmdUI)         
{   
	pCmdUI->SetCheck(bOnTop==1);
}

void CHtmlcopDlg::OnOptionsDelphimode() 
{
	if (bDelphi!=1)
	{
		bHTML=0;
		bDelphi=1;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnViewHtmlhexmode() 
{
	if (bHTML!=1)
	{
		bHTML=1;
		bDelphi=0;
	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnOptionsAutocopytoclipboard() 
{
	bAutoCopy=bAutoCopy?0:1;
	if (bAutoCopy) OnCopytoclip();
}

void CHtmlcopDlg::OnColorRandom() 
{
	// Generates a random color and updates
	// current decimal value MOD 256 - make a random value from 0 to 255
    srand((unsigned) time(NULL));	// seed with the timer to actually make it random
    m_Reddec=rand() % 256;
	m_Greendec=rand() % 256;
	m_Bluedec=rand() % 256;
	UpdateData(false);
	OnconvertRGB();
}

void CHtmlcopDlg::OnFileAbout() 
{
	// bring up the About Dialog

	CAboutDlg dlg; 
	dlg.DoModal();
}

void CHtmlcopDlg::OnColorSnaptowebsafe() 
{

	bSnaptoWebsafe=bSnaptoWebsafe?0:1;
	
	if ((!bSnaptoWebsafe) && (bOldClrExist)) 
	{
		// the user switched snap to websafe off, which means it was previously on
		// revert back to the saved colors
		m_Reddec   = m_OldRed;
		m_Greendec = m_OldGreen;
		m_Bluedec  = m_OldBlue;

	}
	OnconvertRGB();
}

void CHtmlcopDlg::OnUpdateColorSnaptowebsafe(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(bSnaptoWebsafe == 1); 
}

void CHtmlcopDlg::TestForWebsafe()
{
	// websafe colors are multiples of 51
	if (bSnaptoWebsafe)
	{
		bOldClrExist = true;	// let the other function know we have an old color
		m_OldRed   = m_Reddec;	// backup the actual values incase they unsnap
		m_OldGreen = m_Greendec;
		m_OldBlue  = m_Bluedec;

		m_Reddec   = DecimaltoWebsafe(m_Reddec);
		m_Greendec = DecimaltoWebsafe(m_Greendec);
		m_Bluedec  = DecimaltoWebsafe(m_Bluedec);
	} //else  do nothing
}

int CHtmlcopDlg::DecimaltoWebsafe(int originalDec)
{
	int offset = originalDec % 51;
	
	// see if this value is already websafe
	if (offset == 0)
	{
		return originalDec;		// Great, it was already a multiple of 51;
	} else {
		if (offset < 25)
			return originalDec - (offset);
		else
			return (((originalDec / 51) + 1) * 51);
	}
}

void CHtmlcopDlg::OnOptionsOmitsymbol() 
{
    bOmitPound=bOmitPound?0:1;
    FigurePound();
}

void CHtmlcopDlg::FigurePound() 
{
	// This function adds or removes characters from the hex edit control

    if (bOmitPound) 
	{
		if (bHTML) {
			if (m_Hexcolor.Left(1) == '#')			// remove the # is it exists
				m_Hexcolor.Delete(0); 
		} else if (bDelphi) {
	        if (m_Hexcolor.Left(1) == '$') 
				m_Hexcolor.Delete(0);
		}
    }
    else
    {
		if (bHTML) {
			if (m_Hexcolor.Left(1) != '#')  
				m_Hexcolor = "#" + m_Hexcolor;		// add the # if it exsits
		} else if (bDelphi) {
	        if (m_Hexcolor.Left(1) != '$') 
				m_Hexcolor = "$" + m_Hexcolor;
		}
    }
	UpdateData(false);								// update changes to the edit control (m_Hexcolor)
}

void CHtmlcopDlg::OnUpdateOptionsOmitsymbol(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(bOmitPound==1);

    if (bDelphi) {
        pCmdUI->SetText(_T("Omit $ Symbol\tCtrl+O"));
    }
    else if (bHTML) {
        pCmdUI->SetText(_T("Omit # Symbol\tCtrl+O"));
    }
}


BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// setup the hyperlinks

	m_link.SetLink(TRUE)
		.SetTextColor(RGB(0,0,255))
		.SetFontUnderline(TRUE)
		.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));

	m_maillink.SetLink(TRUE)
		.SetTextColor(RGB(0,0,255))
		.SetFontUnderline(TRUE)
		.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));
	
	return TRUE;
}

void CHtmlcopDlg::OnExpandDialog() 
{
	m_bExpandedVersion = m_bExpandedVersion?false:true;
	TestForExpand();

}

void CHtmlcopDlg::TestForExpand()
{
	RECT rect ;
	GetWindowRect( &rect ) ;

	if ( !m_bExpandedVersion  ) 
	{
		m_ExpandDialog.SetWindowText( _T("<<") ); 
		MoveWindow(&CCopRect);
	} else {
		MoveWindow(&CCopsmRect);
		m_ExpandDialog.SetWindowText( _T(">>") ) ; 
	}

/*
//		rect.bottom -= 150; //necessary value
//		rect.right -= 50; //necessary value
//		MoveWindow( &rect ) ;
//	
	}
	else
	{
		rect.bottom += 150;
		rect.right += 40;
		MoveWindow( &rect );
	
	} 	*/
}

void CHtmlcopDlg::OnOptionsMinimizetosystray() 
{
	bMinimizetoTray = bMinimizetoTray?0:1;
}

void CHtmlcopDlg::OnUpdateOptionsMinimizetosystray(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(bMinimizetoTray == 1); 
}

void CHtmlcopDlg::OnOptionsUppercasehex() 
{
    bUppercaseHex = bUppercaseHex?0:1;
	TestForUpperHex();
}

void CHtmlcopDlg::OnUpdateOptionsUppercasehex(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(bUppercaseHex == 1); 
}

void CHtmlcopDlg::TestForUpperHex()
{
	// fixes the current hex value to the correct case

	if (bUppercaseHex)
	{
		// make currenthex uppercase
		m_Hexcolor.MakeUpper();
	} else {
		// use lowercase
		m_Hexcolor.MakeLower();
	}
	UpdateData(false);	// update control
}

void CHtmlcopDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//copmenu.LoadMenu(IDR_COPMENU);	

	CMenu tempMenu;
	tempMenu.LoadMenu(IDR_COPMENU);


	ClientToScreen(&point);
	CMenu *pPopup = tempMenu.GetSubMenu(0);
	pPopup->TrackPopupMenu( TPM_LEFTALIGN | TPM_RIGHTBUTTON,
							point.x, point.y, this, NULL);
	//SetMenu(pPopup);

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
	
	CDialog::OnRButtonDown(nFlags, point);
}

void CHtmlcopDlg::OnRButtonUp(UINT nFlags, CPoint point) 
{

	if (m_isEyedropping || m_isMagnifying)
		StopCapture();
	
	CDialog::OnRButtonUp(nFlags, point);
}

void CHtmlcopDlg::WinHelp(DWORD dwData, UINT nCmd) 
{

//	ShellExecute(NULL, "start ColorCop.HLP", NULL);


	CDialog::WinHelp(dwData, nCmd);
}

void CHtmlcopDlg::OnPopupSampling1pixel() 
{
	SampleRate = 1;
}

void CHtmlcopDlg::OnUpdatePopupSampling1pixel(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(SampleRate == 1); 	
}

void CHtmlcopDlg::OnPopupSampling3by3average() 
{
	SampleRate = 3;
}

void CHtmlcopDlg::OnUpdatePopupSampling3by3average(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(SampleRate == 3); 	
}

void CHtmlcopDlg::OnPopupSampling5by5average() 
{
	SampleRate = 5;
}

void CHtmlcopDlg::OnUpdatePopupSampling5by5average(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(SampleRate == 5); 	
}

void CHtmlcopDlg::AveragePixelArea(HDC hdc, int* m_Reddec, int* m_Greendec, int* m_Bluedec, CPoint point)
{
	// this function averages a matrix of pixels.  
	// either a 3 by 3 or a 5 by 5 average of pixels.

	int reddec = 0, greendec = 0, bluedec = 0;		// temp variables to add up the values
	int offset = 0, elements = 0, xrel, yrel;
	COLORREF crefxy;

	if (SampleRate == 3)
	{
		offset = 1;
		elements = 9;		// 3x3 - add up and divide by 9

	} else if (SampleRate == 5) {

		offset = 2;
		elements = 25;		// 5x5 - add up and divide by 25
	}

	for (xrel = point.x - offset;
	     xrel <= point.x + offset;
		 xrel ++)
			for (yrel = point.y - offset;
				 yrel <= point.y + offset;
				 yrel ++)
				 {
						crefxy=::GetPixel(hdc, xrel, yrel);
		
						reddec += GetRValue(crefxy);
						greendec += GetGValue(crefxy);
					    bluedec += GetBValue(crefxy);
				 }

	*m_Reddec   = (int) reddec / elements;
	*m_Greendec = (int) greendec / elements;
	*m_Bluedec  = (int) bluedec / elements;

}
